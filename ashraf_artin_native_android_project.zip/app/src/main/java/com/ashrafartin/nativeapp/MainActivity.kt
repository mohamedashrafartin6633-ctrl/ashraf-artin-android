package com.ashrafartin.nativeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Cream = Color(0xFFF7F4EC)
private val White = Color(0xFFFFFFFF)
private val Green = Color(0xFF17483D)
private val Gold = Color(0xFFC5A66A)
private val Ink = Color(0xFF26332E)
private val Muted = Color(0xFF7D817C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247,244,236)
        window.navigationBarColor = android.graphics.Color.rgb(247,244,236)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { AshrafArtinApp() }
    }
}

@Composable
fun AshrafArtinApp() {
    var selected by remember { mutableStateOf("الرئيسية") }
    var showAdd by remember { mutableStateOf(false) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green, secondary = Gold, background = Cream, surface = White,
            onPrimary = White, onBackground = Ink, onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Cream,
            topBar = { Header() },
            bottomBar = {
                NavigationBar(containerColor = White, contentColor = Green) {
                    val items = listOf(
                        "الرئيسية" to Icons.Default.Home,
                        "القطع" to Icons.Default.Inventory2,
                        "العملاء" to Icons.Default.People,
                        "الحسابات" to Icons.Default.AccountBalanceWallet
                    )
                    items.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selected == label,
                            onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (selected == "الرئيسية" || selected == "القطع") {
                    FloatingActionButton(
                        onClick = { showAdd = true },
                        containerColor = Green, contentColor = White
                    ) { Icon(Icons.Default.Add, contentDescription = "إضافة قطعة") }
                }
            }
        ) { padding ->
            when (selected) {
                "الرئيسية" -> Dashboard(Modifier.padding(padding))
                "القطع" -> EmptySection("سجل القطع", "هنا هتظهر القطع المسجلة من قاعدة بيانات الورشة", Modifier.padding(padding))
                "العملاء" -> EmptySection("العملاء", "المحلات والتجار والزبائن الخاصون", Modifier.padding(padding))
                else -> EmptySection("الحسابات", "المقبوضات والمصروفات وكشف حساب السبت", Modifier.padding(padding))
            }
        }
        if (showAdd) AddPieceDialog(onDismiss = { showAdd = false })
    }
}

@Composable
private fun Header() {
    Column(
        Modifier.fillMaxWidth().background(Cream).padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("أشرف أرتين", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Green)
                Text("إدارة الورشة", fontSize = 13.sp, color = Muted)
            }
            Surface(shape = RoundedCornerShape(14.dp), color = Green) {
                Text("AA", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 15.dp, vertical = 11.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = Gold.copy(alpha = .55f))
    }
}

@Composable
private fun Dashboard(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                color = Green, shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Gold)
            ) {
                Column(Modifier.fillMaxWidth().padding(22.dp)) {
                    Text("مرحبًا بك", color = Color(0xFFE8D8B5), fontSize = 14.sp)
                    Text("أشرف أرتين", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("تلميع وطلاء وصيانة المجوهرات", color = White.copy(alpha = .82f), fontSize = 13.sp)
                }
            }
        }
        item {
            Text("ملخص الورشة", color = Green, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("إجمالي القطع", "—", Icons.Default.Inventory2, Modifier.weight(1f))
                SummaryCard("عدد العملاء", "—", Icons.Default.People, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard("قطع اليوم", "—", Icons.Default.Today, Modifier.weight(1f))
                SummaryCard("قيمة شغل اليوم", "— ج.م", Icons.Default.Payments, Modifier.weight(1f))
            }
        }
        item {
            Surface(color = White, shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = Gold)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("الاتصال بقاعدة البيانات قيد الإعداد", color = Ink, fontWeight = FontWeight.SemiBold)
                        Text("لن نعرض أرقامًا تجريبية على أنها بيانات حقيقية", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            Text("الوصول السريع", color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("تسجيل قطعة", Icons.Default.AddBox, Modifier.weight(1f))
                QuickAction("كشف حساب", Icons.Default.ReceiptLong, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(modifier, color = White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, contentDescription = null, tint = Gold)
            Spacer(Modifier.height(13.dp))
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    OutlinedButton(onClick = {}, modifier.height(58.dp), shape = RoundedCornerShape(14.dp)) {
        Icon(icon, null, tint = Green)
        Spacer(Modifier.width(6.dp))
        Text(label, color = Green, fontSize = 12.sp)
    }
}

@Composable
private fun EmptySection(title: String, description: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Construction, contentDescription = null, tint = Gold, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 23.sp)
        Spacer(Modifier.height(8.dp))
        Text(description, color = Muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Text("سيتم ربط هذه الشاشة ببيانات Supabase الحالية", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun AddPieceDialog(onDismiss: () -> Unit) {
    var customer by remember { mutableStateOf("") }
    var item by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var customerType by remember { mutableStateOf("محل / تاجر") }
    var paid by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل قطعة جديدة", color = Green, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(customer, { customer = it }, label = { Text("اسم العميل") }, singleLine = true)
                OutlinedTextField(item, { item = it }, label = { Text("وصف القطعة") }, singleLine = true)
                OutlinedTextField(price, { price = it }, label = { Text("السعر بالجنيه") }, singleLine = true)
                Text("نوع العميل", color = Green, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = customerType == "محل / تاجر", onClick = { customerType = "محل / تاجر" }, label = { Text("محل / تاجر") })
                    Spacer(Modifier.width(7.dp))
                    FilterChip(selected = customerType == "زبون خاص", onClick = { customerType = "زبون خاص" }, label = { Text("زبون خاص") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = paid, onCheckedChange = { paid = it })
                    Text("تم الحساب وقت الاستلام")
                }
                Text("سيتم تفعيل الحفظ بعد ربط قاعدة البيانات", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("حفظ لاحقًا") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
