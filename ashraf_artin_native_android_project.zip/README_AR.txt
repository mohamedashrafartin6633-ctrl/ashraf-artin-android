مشروع تطبيق أشرف أرتين الأصلي - Android Native

الاختيارات المعتمدة:
- Android فقط في المرحلة الأولى.
- تصميم Light: كريمي وأبيض مع أخضر زمردي وذهبي.
- Online-first.
- الحفاظ على قاعدة بيانات PostgreSQL الحالية في Supabase.

المحتويات الحالية:
- Kotlin + Jetpack Compose.
- شاشة رئيسية أصلية وأقسام تنقل: الرئيسية، القطع، العملاء، الحسابات.
- نموذج أولي لإضافة قطعة يدعم نوع العميل (محل / تاجر أو زبون خاص) وخيار الحساب وقت الاستلام.
- لا توجد بيانات وهمية معروضة على أنها بيانات حقيقية.
- شعار الورشة محفوظ في app/src/main/res/drawable/brand_icon.png.

مهم:
هذه نسخة تأسيس واجهات Native وليست متصلة بقاعدة البيانات بعد.
لن يتم الاتصال مباشرة بقاعدة PostgreSQL من تطبيق الهاتف، ولن توضع DATABASE_URL أو كلمة مرور قاعدة البيانات أو Service Role Key داخل APK.
الخطوة التالية هي تجهيز طبقة API آمنة (Supabase Edge Function أو Backend) وربطها بالجداول الموجودة:
pieces, customer_contacts, client_payments, workshop_expenses, accounting_settings.
يجب مراجعة سياسات RLS وصلاحيات الجداول قبل فتح الوصول للتطبيق.
لا تنفذ أي DROP أو إعادة إنشاء للجداول الموجودة.

بيانات schema المعروفة من نسخة برنامج الورشة:
pieces: id, date, client, item_type, price, received_from, customer_type, paid_immediately
customer_contacts: name, customer_type, phone, landline, whatsapp, address, notes, created_at
client_payments: id, client, customer_type, payment_date, amount, method, notes, created_at
workshop_expenses: id, expense_date, category, description, amount, paid_to, notes, created_at
accounting_settings: id, start_date

إعداد البناء:
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- Java 17
- compileSdk 35

يمكن رفع المشروع إلى مستودع GitHub وبناء APK من خلال GitHub Actions.
