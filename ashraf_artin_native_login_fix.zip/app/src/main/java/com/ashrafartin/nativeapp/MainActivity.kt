package com.ashrafartin.nativeapp

import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Cream = Color(0xFFF7F4EC)
private val White = Color(0xFFFFFFFF)
private val Green = Color(0xFF17483D)
private val Gold = Color(0xFFC5A66A)
private val Ink = Color(0xFF26332E)
private val Muted = Color(0xFF7D817C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.navigationBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { AshrafArtinApp() }
    }
}

@Composable
fun AshrafArtinApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { SecureTokenStore(context) }
    var loggedIn by remember { mutableStateOf(prefs.hasSession()) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Gold, background = Cream, surface = White)) {
        if (loggedIn) {
            HomeScreen(onLogout = { prefs.clear(); loggedIn = false })
        } else {
            LoginScreen(onLogin = { identifier, password ->
                val result = SupabaseLogin.signIn(identifier, password)
                prefs.save(result.first, result.second)
                loggedIn = true
            })
        }
    }
}

@Composable
private fun LoginScreen(onLogin: suspend (String, String) -> Unit) {
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().background(Cream).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(color = Green, shape = RoundedCornerShape(22.dp)) {
            Text("AA", modifier = Modifier.padding(horizontal = 28.dp, vertical = 18.dp), color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(22.dp))
        Text("أشرف أرتين", color = Green, fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Text("إدارة الورشة", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(32.dp))
        Surface(color = White, shape = RoundedCornerShape(22.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("تسجيل الدخول", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = identifier, onValueChange = { identifier = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("اسم المستخدم أو البريد الإلكتروني") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                )
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                Button(
                    onClick = {
                        if (identifier.isBlank() || password.isBlank()) {
                            error = "اكتب اسم المستخدم وكلمة المرور"
                        } else {
                            loading = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { onLogin(identifier.trim(), password) }
                                } catch (e: Exception) {
                                    error = e.message ?: "تعذر تسجيل الدخول، حاول مرة أخرى"
                                } finally { loading = false }
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !loading, colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = White, strokeWidth = 2.dp)
                    else Text("دخول", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Text("بيانات الدخول خاصة بحساب الورشة", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

private object SupabaseLogin {
    fun signIn(identifier: String, password: String): Pair<String, String> {
        require(BuildConfig.SUPABASE_URL.isNotBlank()) { "إعداد SUPABASE_URL غير موجود في بناء التطبيق" }
        require(BuildConfig.SUPABASE_PUBLISHABLE_KEY.isNotBlank()) { "إعداد Publishable Key غير موجود في بناء التطبيق" }
        val endpoint = BuildConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/login-with-username"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        }
        try {
            val body = JSONObject().put("identifier", identifier).put("password", password).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = try { JSONObject(response).optString("error").ifBlank { JSONObject(response).optString("message") } } catch (_: Exception) { "" }
                throw IllegalStateException(message.ifBlank { "فشل تسجيل الدخول (HTTP $code)" })
            }
            val json = JSONObject(response)
            // The Edge Function may return tokens at the root or nested in session/data.session.
            val session = json.optJSONObject("session")
                ?: json.optJSONObject("data")?.optJSONObject("session")
                ?: json.optJSONObject("data")
            val access = firstNonBlank(
                json.optString("access_token"),
                session?.optString("access_token").orEmpty()
            )
            val refresh = firstNonBlank(
                json.optString("refresh_token"),
                session?.optString("refresh_token").orEmpty()
            )
            if (access.isBlank() || refresh.isBlank()) {
                val keys = json.keys().asSequence().toList().joinToString(", ")
                throw IllegalStateException(
                    "استجابة تسجيل الدخول لا تحتوي على access_token و refresh_token. الحقول المستلمة: ${keys.ifBlank { "غير معروفة" }}"
                )
            }
            return access to refresh
        } finally { connection.disconnect() }
    }

    private fun firstNonBlank(vararg values: String): String =
        values.firstOrNull { it.isNotBlank() }.orEmpty()
}

private class SecureTokenStore(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("aa_secure_session", android.content.Context.MODE_PRIVATE)
    fun hasSession(): Boolean = prefs.contains("access") && prefs.contains("refresh")
    fun save(access: String, refresh: String) {
        prefs.edit().putString("access", encrypt(access)).putString("refresh", encrypt(refresh)).apply()
    }
    fun clear() { prefs.edit().clear().apply() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("ashraf_artin_session_key", null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder("ashraf_artin_session_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }
}

@Composable
private fun HomeScreen(onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Cream).padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("أشرف أرتين", color = Green, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("تم تسجيل الدخول بنجاح", color = Muted)
        Surface(color = Green, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("مرحبًا بك", color = Gold, fontSize = 14.sp)
                Text("إدارة الورشة", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("سيتم تفعيل بيانات القطع والعملاء في المرحلة التالية", color = White.copy(alpha = .85f), fontSize = 13.sp)
            }
        }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج", color = Green) }
    }
}
