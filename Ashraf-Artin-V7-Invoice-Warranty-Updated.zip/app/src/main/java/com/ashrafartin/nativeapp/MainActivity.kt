package com.ashrafartin.nativeapp

import android.os.Bundle
import android.content.Intent
import android.graphics.pdf.PdfDocument
import java.io.File
import androidx.core.content.FileProvider
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.time.LocalDate
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Cream = Color(0xFFF7F4EC)
private val White = Color(0xFFFFFFFF)
private val Green = Color(0xFF17483D)
private val Gold = Color(0xFFC5A66A)
private val Ink = Color(0xFF26332E)
private val Muted = Color(0xFF7D817C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.navigationBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { AshrafArtinApp() }
    }
}

@Composable
fun AshrafArtinApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { SecureTokenStore(context) }
    var loggedIn by remember { mutableStateOf(prefs.hasSession()) }
    var accessToken by remember { mutableStateOf(prefs.readSession()?.first.orEmpty()) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Gold, background = Cream, surface = White)) {
        if (loggedIn && accessToken.isNotBlank()) {
            HomeScreen(accessToken = accessToken, onLogout = { prefs.clear(); accessToken = ""; loggedIn = false })
        } else if (loggedIn) {
            LaunchedEffect(Unit) { prefs.clear(); loggedIn = false }
        } else {
            LoginScreen(onLogin = { identifier, password ->
                val result = SupabaseLogin.signIn(identifier, password)
                prefs.save(result.first, result.second)
                accessToken = result.first
                loggedIn = true
            })
        }
    }
}

@Composable
private fun LoginScreen(onLogin: suspend (String, String) -> Unit) {
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().background(Cream).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.brand_logo_card),
            contentDescription = "شعار أشرف أرتين",
            modifier = Modifier.fillMaxWidth().height(190.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(16.dp))
        Text("إدارة الورشة", color = Green, fontSize = 14.sp)
        Spacer(Modifier.height(32.dp))
        Surface(color = White, shape = RoundedCornerShape(22.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("تسجيل الدخول", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = identifier, onValueChange = { identifier = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("اسم المستخدم أو البريد الإلكتروني") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                )
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                Button(
                    onClick = {
                        if (identifier.isBlank() || password.isBlank()) {
                            error = "اكتب اسم المستخدم وكلمة المرور"
                        } else {
                            loading = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { onLogin(identifier.trim(), password) }
                                } catch (e: Exception) {
                                    error = e.message ?: "تعذر تسجيل الدخول، حاول مرة أخرى"
                                } finally { loading = false }
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !loading, colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = White, strokeWidth = 2.dp)
                    else Text("دخول", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Text("بيانات الدخول خاصة بحساب الورشة", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

private object SupabaseLogin {
    fun signIn(identifier: String, password: String): Pair<String, String> {
        require(BuildConfig.SUPABASE_URL.isNotBlank()) { "إعداد SUPABASE_URL غير موجود في بناء التطبيق" }
        require(BuildConfig.SUPABASE_PUBLISHABLE_KEY.isNotBlank()) { "إعداد Publishable Key غير موجود في بناء التطبيق" }
        val endpoint = BuildConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/login-with-username"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        }
        try {
            val body = JSONObject().put("identifier", identifier).put("password", password).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = try { JSONObject(response).optString("error").ifBlank { JSONObject(response).optString("message") } } catch (_: Exception) { "" }
                throw IllegalStateException(message.ifBlank { "فشل تسجيل الدخول (HTTP $code)" })
            }
            val json = JSONObject(response)
            // The Edge Function may return tokens at the root or nested in session/data.session.
            val session = json.optJSONObject("session")
                ?: json.optJSONObject("data")?.optJSONObject("session")
                ?: json.optJSONObject("data")
            val access = firstNonBlank(
                json.optString("access_token"),
                session?.optString("access_token").orEmpty()
            )
            val refresh = firstNonBlank(
                json.optString("refresh_token"),
                session?.optString("refresh_token").orEmpty()
            )
            if (access.isBlank() || refresh.isBlank()) {
                val keys = json.keys().asSequence().toList().joinToString(", ")
                throw IllegalStateException(
                    "استجابة تسجيل الدخول لا تحتوي على access_token و refresh_token. الحقول المستلمة: ${keys.ifBlank { "غير معروفة" }}"
                )
            }
            return access to refresh
        } finally { connection.disconnect() }
    }

    private fun firstNonBlank(vararg values: String): String =
        values.firstOrNull { it.isNotBlank() }.orEmpty()
}

private class SecureTokenStore(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("aa_secure_session", android.content.Context.MODE_PRIVATE)
    fun hasSession(): Boolean = prefs.contains("access") && prefs.contains("refresh")
    fun readSession(): Pair<String, String>? {
        return try {
            val access = prefs.getString("access", null) ?: return null
            val refresh = prefs.getString("refresh", null) ?: return null
            decrypt(access) to decrypt(refresh)
        } catch (_: Exception) {
            clear()
            null
        }
    }
    fun save(access: String, refresh: String) {
        prefs.edit().putString("access", encrypt(access)).putString("refresh", encrypt(refresh)).apply()
    }
    fun clear() { prefs.edit().clear().apply() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("ashraf_artin_session_key", null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder("ashraf_artin_session_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
    private fun decrypt(value: String): String {
        val parts = value.split(":", limit = 2)
        require(parts.size == 2) { "بيانات الجلسة غير صالحة" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }
}

@Composable
private fun HomeScreen(accessToken: String, onLogout: () -> Unit) {
    var role by remember(accessToken) { mutableStateOf<String?>(null) }
    var profileLoading by remember(accessToken) { mutableStateOf(true) }
    var profileError by remember(accessToken) { mutableStateOf<String?>(null) }
    var homePieces by remember(accessToken) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var homeCustomers by remember(accessToken) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var selected by remember { mutableStateOf<String?>(null) }
    var showExitDialog by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    LaunchedEffect(accessToken) {
        profileLoading = true
        profileError = null
        try {
            role = withContext(Dispatchers.IO) {
                val user = SupabaseData.currentUser(accessToken)
                SupabaseData.profile(user.getString("id"), accessToken).getString("role")
            }
        } catch (e: Exception) {
            profileError = e.message ?: "تعذر التحقق من صلاحيات الحساب"
        } finally { profileLoading = false }
    }

    LaunchedEffect(accessToken, role, selected) {
        if (selected == null && (role == "owner" || role == "employee")) {
            try {
                val pair = withContext(Dispatchers.IO) {
                    val pieces = SupabaseData.select("app_pieces", accessToken, "select=id,customer_id,item_type,price,status&order=id.desc&limit=5")
                    val customers = SupabaseData.select("app_customers", accessToken, "select=id,name&order=name.asc&limit=5000")
                    (0 until pieces.length()).map { pieces.getJSONObject(it) } to
                        (0 until customers.length()).map { customers.getJSONObject(it) }
                }
                homePieces = pair.first
                homeCustomers = pair.second
            } catch (_: Exception) {
                // The dashboard remains usable if recent activity cannot be loaded.
            }
        }
    }

    val ownerTiles = listOf(
        Triple("العملاء", "بيانات العملاء", Icons.Default.People),
        Triple("القطع", "استلام ومتابعة الأعمال", Icons.Default.Diamond),
        Triple("المدفوعات", "التحصيل", Icons.Default.AccountBalanceWallet),
        Triple("المصروفات", "مصروفات الورشة", Icons.Default.AccountBalanceWallet),
        Triple("الفواتير والضمان", "إصدار المستندات", Icons.Default.ReceiptLong),
        Triple("سجل المحلات", "حسابات المحلات", Icons.Default.Inventory2),
        Triple("التقارير", "متابعة الأداء", Icons.Default.BarChart)
    )
    val employeeTiles = listOf(
        Triple("العملاء", "بيانات العملاء", Icons.Default.People),
        Triple("القطع", "استلام ومتابعة الأعمال", Icons.Default.Diamond),
        Triple("الفواتير والضمان", "شهادات الضمان", Icons.Default.VerifiedUser)
    )
    val tiles = when (role) {
        "owner" -> ownerTiles
        "employee" -> employeeTiles
        else -> emptyList()
    }

    if (selected != null) {
        DataSectionScreen(section = selected!!, accessToken = accessToken, role = role.orEmpty(), onBack = { selected = null })
        return
    }

    BackHandler(enabled = true) { showExitDialog = true }

    Column(
        Modifier.fillMaxSize().background(Cream).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("أهلاً بيك", color = Muted, fontSize = 13.sp)
                Text("إدارة أشرف أرتين", color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("إدارة الورشة بسهولة", color = Muted, fontSize = 12.sp)
            }
            Image(
                painter = painterResource(id = R.drawable.brand_logo_card),
                contentDescription = "شعار أشرف أرتين",
                modifier = Modifier.width(104.dp).height(62.dp),
                contentScale = ContentScale.Fit
            )
        }

        Surface(color = Color(0xFFEAF0EC), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("كل شغلك في مكان واحد", color = Green, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("اختار القسم اللي محتاجه وابدأ مباشرة", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.Diamond, contentDescription = null, tint = Color(0xFF759589), modifier = Modifier.size(34.dp))
            }
        }

        if (profileLoading) {
            Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Green, strokeWidth = 2.dp)
            }
        } else if (profileError != null) {
            Text(profileError!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            Text("تم إيقاف عرض الأقسام لحين التحقق من صلاحية الحساب.", color = Muted, fontSize = 12.sp)
        } else {
            Text("الأقسام الرئيسية", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            tiles.chunked(2).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    rowItems.forEach { tile ->
                        Card(
                            onClick = { selected = tile.first },
                            modifier = Modifier.weight(1f).heightIn(min = 112.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 14.dp),
                                horizontalAlignment = Alignment.Start,
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                Surface(color = Color(0xFFEAF0EC), shape = RoundedCornerShape(12.dp), modifier = Modifier.size(38.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(tile.third, contentDescription = null, tint = Green, modifier = Modifier.size(21.dp))
                                    }
                                }
                                Text(tile.first, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(tile.second, color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            Surface(color = White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("آخر القطع المسجلة", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { selected = "القطع" }, contentPadding = PaddingValues(0.dp)) {
                            Text("عرض الكل", color = Green, fontSize = 12.sp)
                        }
                    }
                    if (homePieces.isEmpty()) {
                        Text("لا توجد قطع حديثة للعرض.", color = Muted, fontSize = 12.sp)
                    } else {
                        homePieces.forEachIndexed { index, piece ->
                            if (index > 0) HorizontalDivider(color = Color(0xFFECEEEB))
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(piece.optString("item_type").ifBlank { "قطعة بدون وصف" }, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    val customer = homeCustomers.firstOrNull { it.optLong("id") == piece.optLong("customer_id") }?.optString("name").orEmpty()
                                    Text(customer.ifBlank { "عميل" }, color = Muted, fontSize = 11.sp)
                                }
                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(when (piece.optString("status")) {
                                        "received" -> "تم الاستلام"
                                        "in_progress" -> "قيد التنفيذ"
                                        "completed" -> "مكتملة"
                                        "delivered" -> "تم التسليم"
                                        else -> piece.optString("status").ifBlank { "مسجلة" }
                                    }, color = Green, fontSize = 11.sp)
                                    if (role == "owner") Text("${piece.optString("price")} ج.م", color = Muted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Green)
        ) { Text("تسجيل الخروج") }
        Spacer(Modifier.height(6.dp))
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text("الخروج من التطبيق", color = Green) },
            text = { Text("هل تريد إغلاق تطبيق أشرف أرتين؟") },
            confirmButton = {
                TextButton(onClick = {
                    showExitDialog = false
                    (context as? ComponentActivity)?.finish()
                }) { Text("خروج", color = Green) }
            },
            dismissButton = { TextButton(onClick = { showExitDialog = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun DocumentHubScreen(accessToken: String, role: String, onBack: () -> Unit) {
    var selectedDocument by remember { mutableStateOf<String?>(null) }
    if (selectedDocument != null) {
        DataSectionScreen(
            section = selectedDocument!!,
            accessToken = accessToken,
            role = role,
            onBack = { selectedDocument = null }
        )
        return
    }
    BackHandler(enabled = true, onBack = onBack)
    val isOwner = role == "owner"
    Column(
        Modifier.fillMaxSize().background(Cream).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("رجوع", color = Green) }
            Spacer(Modifier.width(8.dp))
            Text("الفواتير والضمان", color = Green, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Text("اختار المستند اللي محتاجه", color = Muted, fontSize = 13.sp)
        Card(
            onClick = { if (isOwner) selectedDocument = "الفواتير" },
            enabled = isOwner,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = White, disabledContainerColor = Color(0xFFF0F0EB)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color(0xFFEAF0EC), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(48.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Green, modifier = Modifier.size(25.dp)) }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الفواتير", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(if (isOwner) "إنشاء ومراجعة ومشاركة فواتير الخدمات" else "الفواتير متاحة لحساب المالك فقط", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.MoreHoriz, contentDescription = null, tint = Muted)
            }
        }
        Card(
            onClick = { selectedDocument = "الضمان" },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(color = Color(0xFFF3EEDF), shape = RoundedCornerShape(13.dp), modifier = Modifier.size(48.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF997A43), modifier = Modifier.size(25.dp)) }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("شهادات الضمان", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("إصدار شهادة لعميل وقطعة محددين أو مشاركة شهادة سابقة", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.MoreHoriz, contentDescription = null, tint = Muted)
            }
        }
        Text("ملاحظة: إصدار الفاتورة لا ينشئ شهادة ضمان تلقائيًا. الضمان اختياري ويصدر للقطع التي تحددها فقط.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun WarrantyDraftForm(accessToken: String, onCancel: () -> Unit, onCreated: () -> Unit) {
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var pieces by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var customerId by remember { mutableStateOf("") }
    var pieceId by remember { mutableStateOf("") }
    var customerMenu by remember { mutableStateOf(false) }
    var pieceMenu by remember { mutableStateOf(false) }
    var serviceDescription by remember { mutableStateOf("") }
    var warrantyPeriod by remember { mutableStateOf("") }
    var validUntil by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val selectedCustomer = customers.firstOrNull { it.optString("id") == customerId }
    val customerPieces = pieces.filter { it.optString("customer_id") == customerId }
    val selectedPiece = customerPieces.firstOrNull { it.optString("id") == pieceId }

    LaunchedEffect(accessToken) {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) {
                val customerRows = SupabaseData.select("app_customers", accessToken, "select=id,name&order=name.asc&limit=5000")
                val pieceRows = SupabaseData.select("app_pieces", accessToken, "select=id,customer_id,item_type,received_from&order=id.desc&limit=10000")
                (0 until customerRows.length()).map { customerRows.getJSONObject(it) } to
                    (0 until pieceRows.length()).map { pieceRows.getJSONObject(it) }
            }
            customers = result.first
            pieces = result.second
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحميل العملاء والقطع"
        } finally { loading = false }
    }

    Surface(color = White, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("إصدار شهادة ضمان اختيارية", color = Green, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text("الشهادة لا تصدر إلا بعد اختيار العميل والقطعة يدويًا.", color = Muted, fontSize = 12.sp)
            if (loading) {
                Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
            } else {
                Box {
                    OutlinedButton(onClick = { customerMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedCustomer?.optString("name") ?: "اختيار العميل")
                    }
                    DropdownMenu(expanded = customerMenu, onDismissRequest = { customerMenu = false }) {
                        customers.forEach { customer ->
                            DropdownMenuItem(
                                text = { Text(customer.optString("name")) },
                                onClick = { customerId = customer.optString("id"); pieceId = ""; customerMenu = false }
                            )
                        }
                    }
                }
                Box {
                    OutlinedButton(onClick = { pieceMenu = true }, enabled = customerId.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                        Text(selectedPiece?.optString("item_type") ?: "اختيار القطعة")
                    }
                    DropdownMenu(expanded = pieceMenu, onDismissRequest = { pieceMenu = false }) {
                        customerPieces.forEach { piece ->
                            val receiver = piece.optString("received_from").takeUnless { it == "null" }.orEmpty()
                            DropdownMenuItem(
                                text = { Text(piece.optString("item_type") + if (receiver.isNotBlank()) " — سلّمها $receiver" else "") },
                                onClick = { pieceId = piece.optString("id"); pieceMenu = false }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = serviceDescription,
                    onValueChange = { serviceDescription = it },
                    label = { Text("الخدمة التي يغطيها الضمان") },
                    placeholder = { Text("مثال: إعادة طلاء الروديوم") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = warrantyPeriod,
                    onValueChange = { warrantyPeriod = it },
                    label = { Text("مدة الضمان (اختياري)") },
                    placeholder = { Text("مثال: 3 أشهر") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                OutlinedTextField(
                    value = validUntil,
                    onValueChange = { validUntil = it.filter { c -> c.isDigit() || c == '-' }.take(10) },
                    label = { Text("تاريخ انتهاء الضمان (اختياري: YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات إضافية (اختياري)") }, modifier = Modifier.fillMaxWidth())
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f), enabled = !saving) { Text("إلغاء") }
                    Button(
                        onClick = {
                            when {
                                customerId.isBlank() -> error = "اختر العميل"
                                pieceId.isBlank() -> error = "اختر القطعة التي ستصدر لها الشهادة"
                                serviceDescription.isBlank() -> error = "اكتب الخدمة التي يغطيها الضمان"
                                validUntil.isNotBlank() && runCatching { LocalDate.parse(validUntil) }.isFailure -> error = "اكتب تاريخ انتهاء صحيحًا بصيغة YYYY-MM-DD"
                                else -> {
                                    saving = true
                                    error = null
                                    scope.launch {
                                        try {
                                            withContext(Dispatchers.IO) {
                                                val user = SupabaseData.currentUser(accessToken)
                                                val now = java.time.OffsetDateTime.now().toString()
                                                val payload = JSONObject()
                                                    .put("customer_id", customerId.toLong())
                                                    .put("piece_id", pieceId.toLong())
                                                    .put("service_description", serviceDescription.trim())
                                                    .put("warranty_period", warrantyPeriod.trim().ifBlank { JSONObject.NULL })
                                                    .put("valid_until", validUntil.trim().ifBlank { JSONObject.NULL })
                                                    .put("issued_at", now)
                                                    .put("issued_by", user.getString("id"))
                                                    .put("status", "issued")
                                                    .put("notes", notes.trim().ifBlank { JSONObject.NULL })
                                                    .put("created_at", now)
                                                val created = SupabaseData.insert("app_warranties", accessToken, payload)
                                                check(created.length() > 0) { "لم يتم إنشاء شهادة الضمان" }
                                            }
                                            onCreated()
                                        } catch (e: Exception) {
                                            error = e.message ?: "تعذر إصدار شهادة الضمان"
                                        } finally { saving = false }
                                    }
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        enabled = !saving,
                        colors = ButtonDefaults.buttonColors(containerColor = Green)
                    ) {
                        if (saving) CircularProgressIndicator(Modifier.size(18.dp), color = White) else Text("إصدار الشهادة", color = White)
                    }
                }
            }
        }
    }
}

@Composable
private fun DataSectionScreen(section: String, accessToken: String, role: String, onBack: () -> Unit) {
    if (section == "الفواتير والضمان") {
        DocumentHubScreen(accessToken = accessToken, role = role, onBack = onBack)
        return
    }
    BackHandler(enabled = true, onBack = onBack)
    val allowed = role == "owner" || (role == "employee" && section in setOf("العملاء", "القطع", "الضمان"))
    val table = when (section) {
        "العملاء" -> "app_customers"
        "القطع" -> "app_pieces"
        "المدفوعات" -> "app_payments"
        "المصروفات" -> "app_expenses"
        "الفواتير" -> "app_invoices"
        "الضمان" -> "app_warranties"
        else -> null
    }
    var rows by remember(section) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember(section) { mutableStateOf(table != null) }
    var error by remember(section) { mutableStateOf<String?>(null) }
    var showNewPiece by remember { mutableStateOf(false) }
    var editingPiece by remember { mutableStateOf<JSONObject?>(null) }
    var pieceEditType by remember { mutableStateOf("") }
    var pieceEditDescription by remember { mutableStateOf("") }
    var pieceEditPrice by remember { mutableStateOf("") }
    var pieceEditReceivedFrom by remember { mutableStateOf("") }
    var deletingPiece by remember { mutableStateOf<JSONObject?>(null) }
    var editingCustomer by remember { mutableStateOf<JSONObject?>(null) }
    var customerEditName by remember { mutableStateOf("") }
    var customerEditType by remember { mutableStateOf("shop") }
    var customerEditAddress by remember { mutableStateOf("") }
    var customerEditNotes by remember { mutableStateOf("") }
    var customerEditPhone by remember { mutableStateOf("") }
    var customerEditWhatsapp by remember { mutableStateOf("") }
    var customerContacts by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var showNewExpense by remember { mutableStateOf(false) }
    var showNewPayment by remember { mutableStateOf(false) }
    var paymentCustomerId by remember { mutableStateOf("") }
    var paymentAmount by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("cash") }
    var paymentReference by remember { mutableStateOf("") }
    var paymentNotes by remember { mutableStateOf("") }
    var paymentMenu by remember { mutableStateOf(false) }
    var paymentMethodMenu by remember { mutableStateOf(false) }
    var expenseCategory by remember { mutableStateOf("") }
    var expenseDescription by remember { mutableStateOf("") }
    var expenseAmount by remember { mutableStateOf("") }
    var expensePaidTo by remember { mutableStateOf("") }
    var expenseNotes by remember { mutableStateOf("") }
    var showNewInvoice by remember { mutableStateOf(false) }
    var showNewWarranty by remember { mutableStateOf(false) }
    var customerName by remember { mutableStateOf("") }
    var customerType by remember { mutableStateOf("shop") }
    var customerTypeMenu by remember { mutableStateOf(false) }
    var itemType by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var receivedFrom by remember { mutableStateOf("") }
    var paidImmediately by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    suspend fun loadRows() {
        val result = withContext(Dispatchers.IO) {
            val query = if (section == "العملاء") "select=*&order=name.asc&limit=5000" else "select=*&order=id.desc&limit=1000"
            SupabaseData.select(table!!, accessToken, query)
        }
        rows = (0 until result.length()).map { result.getJSONObject(it) }
        if (section == "العملاء") {
            val contactsResult = withContext(Dispatchers.IO) {
                try {
                    SupabaseData.select("app_customer_contacts", accessToken, "select=id,customer_id,phone,whatsapp,is_primary&order=is_primary.desc&limit=5000")
                } catch (_: Exception) {
                    SupabaseData.select("app_customer_contacts", accessToken, "select=id,customer_id,phone,is_primary&order=is_primary.desc&limit=5000")
                }
            }
            customerContacts = (0 until contactsResult.length()).map { contactsResult.getJSONObject(it) }
        }
    }

    LaunchedEffect(section, accessToken) {
        if (table != null) {
            try {
                if (section == "القطع" || section == "المدفوعات" || section == "الضمان") {
                    val customerResult = withContext(Dispatchers.IO) {
                        SupabaseData.select("app_customers", accessToken, "select=id,name&order=name.asc&limit=500")
                    }
                    customers = (0 until customerResult.length()).map { customerResult.getJSONObject(it) }
                    if (paymentCustomerId.isBlank() && customers.isNotEmpty()) paymentCustomerId = customers.first().optString("id")
                }
                loadRows()
            } catch (e: Exception) { error = e.message ?: "تعذر تحميل البيانات" }
            finally { loading = false }
        }
    }

    Column(Modifier.fillMaxSize().background(Cream).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع", color = Green) }
            Text(section, color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (!allowed || (role !in setOf("owner", "employee"))) {
            Text("غير مسموح لهذا الحساب بفتح القسم.", color = MaterialTheme.colorScheme.error)
            return@Column
        }
        if (section == "سجل المحلات" || section == "التقارير") {
            if (role != "owner") {
                Text("هذا القسم متاح للمالك فقط.", color = MaterialTheme.colorScheme.error)
            } else {
                OwnerFinanceSection(section = section, accessToken = accessToken)
            }
            return@Column
        }
        if (section == "القطع" && !showNewPiece) {
            Button(onClick = { showNewPiece = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(14.dp)) {
                Text("+ تسجيل قطعة جديدة", color = White)
            }
        }
        if (section == "المصروفات" && !showNewExpense) {
            Button(onClick = { showNewExpense = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("+ تسجيل مصروف", color = White) }
        }
        if (section == "المدفوعات" && !showNewPayment) {
            Button(onClick = { showNewPayment = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("+ تسجيل دفعة عميل", color = White) }
        }
        if (section == "الفواتير" && !showNewInvoice) {
            Button(onClick = { showNewInvoice = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("+ إنشاء فاتورة", color = White) }
        }
        if (section == "الضمان" && role == "owner" && !showNewWarranty) {
            Button(onClick = { showNewWarranty = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("+ إصدار شهادة ضمان لقطعة محددة", color = White) }
        }
        if (section == "العملاء") {
            Text("إدارة بيانات العملاء", color = Green, fontWeight = FontWeight.Bold)
        }
        if (section == "المصروفات" && showNewExpense) {
            Surface(color = White, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مصروف جديد", color = Green, fontWeight = FontWeight.Bold)
                    OutlinedTextField(expenseCategory, { expenseCategory = it }, label = { Text("تصنيف المصروف") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expenseDescription, { expenseDescription = it }, label = { Text("وصف المصروف") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expenseAmount, { expenseAmount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("المبلغ بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expensePaidTo, { expensePaidTo = it }, label = { Text("صُرف إلى (اختياري)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expenseNotes, { expenseNotes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showNewExpense = false }, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                        Button(onClick = {
                            val v = expenseAmount.toBigDecimalOrNull()
                            if (expenseCategory.isBlank() || expenseDescription.isBlank() || v == null || v <= java.math.BigDecimal.ZERO) saveMessage = "أكمل التصنيف والوصف واكتب مبلغًا صحيحًا أكبر من صفر"
                            else { saving = true; scope.launch { try {
                                val user = withContext(Dispatchers.IO) { SupabaseData.currentUser(accessToken) }
                                val now = java.time.OffsetDateTime.now().toString()
                                val payload = JSONObject().put("expense_date", now).put("category", expenseCategory.trim()).put("description", expenseDescription.trim()).put("amount", v).put("paid_to", expensePaidTo.trim().ifBlank { JSONObject.NULL }).put("notes", expenseNotes.trim().ifBlank { JSONObject.NULL }).put("idempotency_key", java.util.UUID.randomUUID().toString()).put("created_by", user.getString("id")).put("created_at", now)
                                withContext(Dispatchers.IO) { SupabaseData.insert("app_expenses", accessToken, payload) }; loadRows(); showNewExpense = false; expenseCategory = ""; expenseDescription = ""; expenseAmount = ""; expensePaidTo = ""; expenseNotes = ""; saveMessage = "تم تسجيل المصروف"
                            } catch(e: Exception) { saveMessage = e.message ?: "تعذر تسجيل المصروف" } finally { saving = false } } }
                        }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("حفظ المصروف", color = White) }
                    }
                    if (saveMessage != null) Text(saveMessage!!, color = Green)
                }
            }
        }
        if (section == "المدفوعات" && showNewPayment) {
            Surface(color = White, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("تسجيل دفعة عميل", color = Green, fontWeight = FontWeight.Bold)
                    Box {
                        OutlinedButton(onClick = { paymentMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(customers.firstOrNull { it.optString("id") == paymentCustomerId }?.optString("name") ?: "اختيار العميل")
                        }
                        DropdownMenu(expanded = paymentMenu, onDismissRequest = { paymentMenu = false }) {
                            customers.forEach { c -> DropdownMenuItem(text = { Text(c.optString("name")) }, onClick = { paymentCustomerId = c.optString("id"); paymentMenu = false }) }
                        }
                    }
                    OutlinedTextField(paymentAmount, { paymentAmount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("المبلغ بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    Box {
                        OutlinedButton(onClick = { paymentMethodMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(when (paymentMethod) { "cash" -> "نقدي"; "bank_transfer" -> "تحويل بنكي"; "instapay" -> "إنستاباي"; else -> "أخرى" })
                        }
                        DropdownMenu(expanded = paymentMethodMenu, onDismissRequest = { paymentMethodMenu = false }) {
                            listOf("cash" to "نقدي", "bank_transfer" to "تحويل بنكي", "instapay" to "إنستاباي", "other" to "أخرى").forEach { (value, label) ->
                                DropdownMenuItem(text = { Text(label) }, onClick = { paymentMethod = value; paymentMethodMenu = false })
                            }
                        }
                    }
                    OutlinedTextField(paymentReference, { paymentReference = it }, label = { Text("رقم مرجعي (اختياري)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(paymentNotes, { paymentNotes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showNewPayment = false }, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                        Button(onClick = {
                            val amountValue = paymentAmount.toBigDecimalOrNull()
                            if (paymentCustomerId.isBlank() || amountValue == null || amountValue <= java.math.BigDecimal.ZERO) {
                                saveMessage = "اختر العميل واكتب مبلغًا صحيحًا أكبر من صفر"
                            } else {
                                saving = true
                                scope.launch {
                                    try {
                                        val user = withContext(Dispatchers.IO) { SupabaseData.currentUser(accessToken) }
                                        val now = java.time.OffsetDateTime.now().toString()
                                        val payload = JSONObject()
                                            .put("customer_id", paymentCustomerId.toLong())
                                            .put("amount", amountValue)
                                            .put("payment_date", now)
                                            .put("payment_method", paymentMethod)
                                            .put("reference_number", paymentReference.trim().ifBlank { JSONObject.NULL })
                                            .put("notes", paymentNotes.trim().ifBlank { JSONObject.NULL })
                                            .put("idempotency_key", java.util.UUID.randomUUID().toString())
                                            .put("created_by", user.getString("id"))
                                            .put("created_at", now)
                                        withContext(Dispatchers.IO) { SupabaseData.insert("app_payments", accessToken, payload) }
                                        loadRows()
                                        showNewPayment = false; paymentAmount = ""; paymentReference = ""; paymentNotes = ""; paymentMethod = "cash"
                                        saveMessage = "تم تسجيل الدفعة بنجاح"
                                    } catch (e: Exception) { saveMessage = e.message ?: "تعذر تسجيل الدفعة" }
                                    finally { saving = false }
                                }
                            }
                        }, modifier = Modifier.weight(1f), enabled = !saving, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                            if (saving) CircularProgressIndicator(Modifier.size(18.dp), color = White) else Text("حفظ الدفعة", color = White)
                        }
                    }
                    if (saveMessage != null) Text(saveMessage!!, color = Green)
                }
            }
        }
        if (section == "الفواتير" && showNewInvoice) {
            InvoiceDraftForm(accessToken = accessToken, onCancel = { showNewInvoice = false }, onCreated = { scope.launch { loadRows(); showNewInvoice = false; saveMessage = "تم إنشاء مسودة الفاتورة" } })
        }
        if (section == "الضمان" && showNewWarranty && role == "owner") {
            WarrantyDraftForm(
                accessToken = accessToken,
                onCancel = { showNewWarranty = false },
                onCreated = { scope.launch { loadRows(); showNewWarranty = false; saveMessage = "تم إصدار شهادة الضمان بنجاح" } }
            )
        }
        if (section == "القطع" && showNewPiece) {
            Surface(color = White, shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تسجيل قطعة جديدة", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it; saveMessage = null },
                        label = { Text("اسم العميل") },
                        placeholder = { Text("اكتب اسم العميل يدويًا") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Box {
                        OutlinedButton(onClick = { customerTypeMenu = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Text(if (customerType == "shop") "نوع العميل: محل / تاجر" else "نوع العميل: عميل خاص", color = Ink)
                        }
                        DropdownMenu(expanded = customerTypeMenu, onDismissRequest = { customerTypeMenu = false }) {
                            DropdownMenuItem(text = { Text("محل / تاجر") }, onClick = { customerType = "shop"; customerTypeMenu = false })
                            DropdownMenuItem(text = { Text("عميل خاص") }, onClick = { customerType = "private"; customerTypeMenu = false })
                        }
                    }
                    OutlinedTextField(value = itemType, onValueChange = { itemType = it }, label = { Text("نوع القطعة (مثال: خاتم)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = price, onValueChange = { price = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("السعر بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(value = receivedFrom, onValueChange = { receivedFrom = it }, label = { Text("اسم الشخص الذي سلّم القطعة (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = paidImmediately, onCheckedChange = { paidImmediately = it })
                        Text("تم الدفع فورًا", color = Ink, fontSize = 14.sp)
                    }
                    if (saveMessage != null) Text(saveMessage!!, color = if (saveMessage!!.startsWith("تم")) Green else MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showNewPiece = false }, modifier = Modifier.weight(1f), enabled = !saving) { Text("إلغاء") }
                        Button(onClick = {
                            val amount = price.toBigDecimalOrNull()
                            when {
                                customerName.isBlank() -> saveMessage = "اكتب اسم العميل أولًا"
                                itemType.isBlank() -> saveMessage = "اكتب نوع القطعة"
                                amount == null || amount < java.math.BigDecimal.ZERO -> saveMessage = "اكتب سعرًا صحيحًا"
                                else -> {
                                    saving = true
                                    saveMessage = null
                                    scope.launch {
                                        try {
                                            val customerId = withContext(Dispatchers.IO) {
                                                val encodedName = java.net.URLEncoder.encode(customerName.trim(), "UTF-8")
                                                val found = SupabaseData.select("app_customers", accessToken, "select=id,name&name=eq.$encodedName&customer_type=eq.$customerType&limit=1")
                                                if (found.length() > 0) {
                                                    found.getJSONObject(0).getLong("id")
                                                } else {
                                                    val newCustomer = JSONObject()
                                                        .put("name", customerName.trim())
                                                        .put("customer_type", customerType)
                                                    val created = SupabaseData.insert("app_customers", accessToken, newCustomer)
                                                    check(created.length() > 0) { "لم يتم إنشاء العميل" }
                                                    created.getJSONObject(0).getLong("id")
                                                }
                                            }
                                            val payload = JSONObject()
                                                .put("customer_id", customerId)
                                                .put("item_type", itemType.trim())
                                                .put("price", amount)
                                                .put("received_from", receivedFrom.trim().ifBlank { JSONObject.NULL })
                                                .put("paid_immediately", paidImmediately)
                                                .put("status", "received")
                                            val savedPiece = withContext(Dispatchers.IO) { SupabaseData.insert("app_pieces", accessToken, payload) }
                                            val pieceNumber = if (savedPiece.length() > 0) savedPiece.getJSONObject(0).optLong("id") else 0L
                                            val customerNumber = "AA-${customerId.toString().padStart(5, '0')}"
                                            loadRows()
                                            showNewPiece = false
                                            customerName = ""
                                            customerType = "shop"
                                            itemType = ""; description = ""; price = ""; receivedFrom = ""; paidImmediately = false
                                            saveMessage = "تم تسجيل القطعة بنجاح • العميل: $customerNumber • رقم القطعة: $pieceNumber"
                                        } catch (e: Exception) { saveMessage = e.message ?: "تعذر حفظ القطعة" }
                                        finally { saving = false }
                                    }
                                }
                            }
                        }, modifier = Modifier.weight(1f), enabled = !saving, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                            if (saving) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = White, strokeWidth = 2.dp) else Text("حفظ القطعة", color = White)
                        }
                    }
                }
            }
        }
        if (editingCustomer != null) {
            AlertDialog(onDismissRequest = { editingCustomer = null }, title = { Text("تعديل بيانات العميل", color = Green) },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(customerEditName, { customerEditName = it }, label = { Text("اسم العميل") })
                    OutlinedTextField(customerEditPhone, { customerEditPhone = it.filter { ch -> ch.isDigit() || ch == '+' || ch == ' ' } }, label = { Text("رقم الهاتف") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                    OutlinedTextField(customerEditWhatsapp, { customerEditWhatsapp = it.filter { ch -> ch.isDigit() || ch == '+' || ch == ' ' } }, label = { Text("رقم واتساب (اختياري)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                    OutlinedTextField(customerEditAddress, { customerEditAddress = it }, label = { Text("العنوان") })
                    OutlinedTextField(customerEditNotes, { customerEditNotes = it }, label = { Text("ملاحظات") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("نوع العميل", color = Ink)
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { customerEditType = if (customerEditType == "shop") "private" else "shop" }) { Text(if (customerEditType == "shop") "محل / تاجر" else "عميل خاص") }
                    }
                } }, confirmButton = { TextButton(onClick = {
                    val target = editingCustomer ?: return@TextButton
                    if (customerEditName.isBlank()) { saveMessage = "اسم العميل مطلوب" } else {
                        saving = true; scope.launch { try {
                            withContext(Dispatchers.IO) {
                                SupabaseData.update("app_customers", accessToken, "id=eq.${target.optLong("id")}", JSONObject().put("name", customerEditName.trim()).put("customer_type", customerEditType).put("address", customerEditAddress.trim().ifBlank { JSONObject.NULL }).put("notes", customerEditNotes.trim().ifBlank { JSONObject.NULL }).put("updated_at", java.time.OffsetDateTime.now().toString()))
                                val customerId = target.optLong("id")
                                val contactRows = SupabaseData.select("app_customer_contacts", accessToken, "select=id&customer_id=eq.$customerId&order=is_primary.desc&limit=1")
                                val phoneValue = customerEditPhone.trim().ifBlank { null }
                                val whatsappValue = customerEditWhatsapp.trim().ifBlank { null }
                                if (contactRows.length() > 0) {
                                    SupabaseData.update(
                                        "app_customer_contacts", accessToken, "id=eq.${contactRows.getJSONObject(0).optLong("id")}",
                                        JSONObject().put("phone", phoneValue ?: JSONObject.NULL).put("whatsapp", whatsappValue ?: JSONObject.NULL).put("is_primary", true)
                                    )
                                } else if (phoneValue != null || whatsappValue != null) {
                                    SupabaseData.insert(
                                        "app_customer_contacts", accessToken,
                                        JSONObject().put("customer_id", customerId).put("phone", phoneValue ?: JSONObject.NULL)
                                            .put("whatsapp", whatsappValue ?: JSONObject.NULL).put("is_primary", true)
                                    )
                                }
                            }
                            loadRows(); editingCustomer = null; saveMessage = "تم تحديث بيانات العميل"
                        } catch(e: Exception) { saveMessage = e.message ?: "تعذر تعديل العميل" } finally { saving = false } }
                    }
                }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { editingCustomer = null }) { Text("إلغاء") } })
        }
        if (editingPiece != null) {
            AlertDialog(
                onDismissRequest = { editingPiece = null },
                title = { Text("تعديل بيانات القطعة", color = Green) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(pieceEditType, { pieceEditType = it }, label = { Text("نوع القطعة") }, singleLine = true)
                        OutlinedTextField(pieceEditPrice, { pieceEditPrice = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("السعر بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        OutlinedTextField(pieceEditReceivedFrom, { pieceEditReceivedFrom = it }, label = { Text("الشخص الذي سلّم القطعة") })
                    }
                },
                confirmButton = {
                    TextButton(enabled = !saving, onClick = {
                        val target = editingPiece ?: return@TextButton
                        val amount = pieceEditPrice.toBigDecimalOrNull()
                        if (pieceEditType.isBlank() || amount == null || amount < java.math.BigDecimal.ZERO) {
                            saveMessage = "راجع نوع القطعة والسعر"
                        } else {
                            saving = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) {
                                        SupabaseData.update("app_pieces", accessToken, "id=eq.${target.optLong("id")}",
                                            JSONObject().put("item_type", pieceEditType.trim())
                                                .put("price", amount)
                                                .put("received_from", pieceEditReceivedFrom.trim().ifBlank { JSONObject.NULL })
                                                .put("updated_at", java.time.OffsetDateTime.now().toString()))
                                    }
                                    loadRows()
                                    editingPiece = null
                                    saveMessage = "تم تعديل بيانات القطعة"
                                } catch (e: Exception) { saveMessage = "تعذر تعديل القطعة: ${e.message}" }
                                finally { saving = false }
                            }
                        }
                    }) { Text("حفظ التعديلات") }
                },
                dismissButton = { TextButton(onClick = { editingPiece = null }) { Text("إلغاء") } }
            )
        }
        if (deletingPiece != null) {
            AlertDialog(
                onDismissRequest = { deletingPiece = null },
                title = { Text("تأكيد حذف القطعة") },
                text = { Text("هل تريد حذف هذه القطعة نهائيًا؟ لا يمكن التراجع عن الحذف.") },
                confirmButton = {
                    TextButton(enabled = !saving, onClick = {
                        val target = deletingPiece ?: return@TextButton
                        saving = true
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) {
                                    SupabaseData.delete("app_pieces", accessToken, "id=eq.${target.optLong("id")}")
                                }
                                loadRows()
                                deletingPiece = null
                                saveMessage = "تم حذف القطعة"
                            } catch (e: Exception) { saveMessage = "تعذر حذف القطعة: ${e.message}" }
                            finally { saving = false }
                        }
                    }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { deletingPiece = null }) { Text("إلغاء") } }
            )
        }
        when {
            table == null -> Text("هذا القسم لم يتم توصيل عملياته بعد.", color = Muted)
            loading -> Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            rows.isEmpty() -> Text("لا توجد سجلات لعرضها حاليًا.", color = Muted)
            else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("آخر ${rows.size} سجل", color = Muted, fontSize = 12.sp)
                rows.forEach { item ->
                    Surface(color = White, shape = RoundedCornerShape(14.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            val title = when (section) {
                                "العملاء" -> item.optString("name")
                                "القطع" -> item.optString("item_type")
                                "المدفوعات" -> "دفعة رقم ${item.optString("id")}" 
                                "الضمان" -> "شهادة ${item.optString("certificate_number")}" 
                                else -> "فاتورة رقم ${item.optString("invoice_number")}" 
                            }
                            Text(title.ifBlank { "سجل رقم ${item.optString("id")}" }, color = Green, fontWeight = FontWeight.Bold)
                            val detail = when (section) {
                                "العملاء" -> {
                                    val phone = customerContacts.firstOrNull { it.optLong("customer_id") == item.optLong("id") }?.optString("phone").orEmpty()
                                    "النوع: ${if (item.optString("customer_type") == "shop") "محل / تاجر" else "عميل خاص"}" + if (phone.isNotBlank() && phone != "null") "  •  التليفون: $phone" else "  •  لا يوجد رقم مسجل"
                                }
                                "المصروفات" -> "${item.optString("expense_date").take(10)} • ${item.optString("category")} • ${item.optString("description")} • ${item.optString("amount")} ج.م"
                                "القطع" -> "العميل رقم: ${item.optString("customer_id")}  •  السعر: ${item.optString("price")} ج.م"
                                "المدفوعات" -> "العميل: ${item.optString("customer_id")}  •  المبلغ: ${item.optString("amount")}"
                                "الضمان" -> "العميل: ${item.optString("customer_id")} • القطعة: ${item.optString("piece_id")} • الخدمة: ${item.optString("service_description")}"
                                "المصروفات" -> "التاريخ: ${item.optString("expense_date").take(10)}  •  ${item.optString("category")}  •  ${item.optString("amount")} ج.م"
                                else -> "العميل: ${item.optString("customer_id")}  •  الإجمالي: ${item.optString("total_amount")}  •  الحالة: ${item.optString("status")}"
                            }
                            Text(detail, color = Muted, fontSize = 12.sp)
                            if (section == "الضمان") {
                                TextButton(onClick = {
                                    scope.launch {
                                        try {
                                            val number = withContext(Dispatchers.IO) { fetchCustomerWhatsApp(accessToken, item.optLong("customer_id")) }
                                            if (number.isBlank()) android.widget.Toast.makeText(context, "لا يوجد رقم واتساب أو هاتف مسجل لهذا العميل", android.widget.Toast.LENGTH_LONG).show()
                                            else openWhatsAppChat(context, number)
                                        } catch (e: Exception) {
                                            android.widget.Toast.makeText(context, "تعذر فتح محادثة العميل: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }) { Text("فتح واتساب العميل", color = Green) }
                                TextButton(onClick = {
                                    scope.launch {
                                        try {
                                            val warrantyData = withContext(Dispatchers.IO) {
                                                val customer = SupabaseData.select("app_customers", accessToken, "select=id,name,address&id=eq.${item.optLong("customer_id")}&limit=1")
                                                val contact = SupabaseData.select("app_customer_contacts", accessToken, "select=phone,whatsapp&customer_id=eq.${item.optLong("customer_id")}&order=is_primary.desc&limit=1")
                                                if (customer.length() > 0 && contact.length() > 0) {
                                                    val contactRow = contact.getJSONObject(0)
                                                    customer.getJSONObject(0).put("phone", contactRow.optString("phone").takeUnless { it == "null" }.orEmpty())
                                                    customer.getJSONObject(0).put("whatsapp", contactRow.optString("whatsapp").takeUnless { it == "null" }.orEmpty())
                                                }
                                                val piece = SupabaseData.select("app_pieces", accessToken, "select=id,item_type,received_from&id=eq.${item.optLong("piece_id")}&limit=1")
                                                Triple(
                                                    if (customer.length() > 0) customer.getJSONObject(0) else JSONObject().put("name", "عميل"),
                                                    if (piece.length() > 0) piece.getJSONObject(0) else JSONObject().put("item_type", "قطعة"),
                                                    item
                                                )
                                            }
                                            shareWarrantyPdf(context, warrantyData.first, warrantyData.second, warrantyData.third)
                                        } catch (e: Exception) {
                                            android.widget.Toast.makeText(context, "تعذر تجهيز شهادة الضمان: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }) { Text("مشاركة شهادة الضمان PDF", color = Green) }
                            }
                            if (section == "العملاء") {
                                val customerContact = customerContacts.firstOrNull { it.optLong("customer_id") == item.optLong("id") }
                                val preferredNumber = customerContact?.optString("whatsapp").orEmpty().takeUnless { it == "null" }.orEmpty()
                                    .ifBlank { customerContact?.optString("phone").orEmpty().takeUnless { it == "null" }.orEmpty() }
                                if (preferredNumber.isNotBlank()) {
                                    TextButton(onClick = { openWhatsAppChat(context, preferredNumber) }) { Text("فتح واتساب العميل", color = Green) }
                                }
                            }
                            if (section == "العملاء" && role == "owner") {
                                TextButton(onClick = {
                                    editingCustomer = JSONObject(item.toString())
                                    customerEditName = item.optString("name")
                                    customerEditType = item.optString("customer_type", "shop")
                                    customerEditAddress = item.optString("address").takeUnless { it == "null" }.orEmpty()
                                    customerEditNotes = item.optString("notes").takeUnless { it == "null" }.orEmpty()
                                    val contact = customerContacts.firstOrNull { it.optLong("customer_id") == item.optLong("id") }
                                    customerEditPhone = contact?.optString("phone").orEmpty().takeUnless { it == "null" }.orEmpty()
                                    customerEditWhatsapp = contact?.optString("whatsapp").orEmpty().takeUnless { it == "null" }.orEmpty()
                                }) { Text("تعديل بيانات العميل", color = Green) }
                            }
                            if (section == "الفواتير" && role == "owner" && item.optString("status") == "draft") {
                                TextButton(onClick = { scope.launch {
                                    try {
                                        withContext(Dispatchers.IO) {
                                            val user = SupabaseData.currentUser(accessToken)
                                            SupabaseData.update("app_invoices", accessToken, "id=eq.${item.optLong("id")}", JSONObject().put("status", "approved").put("approved_at", java.time.OffsetDateTime.now().toString()).put("approved_by", user.getString("id")))
                                        }
                                        loadRows(); saveMessage = "تم اعتماد الفاتورة"
                                    } catch (e: Exception) { saveMessage = "تعذر اعتماد الفاتورة: ${e.message}" }
                                } }) { Text("اعتماد الفاتورة", color = Green) }
                            }
                            if (section == "الفواتير" && role == "owner") {
                                TextButton(onClick = { scope.launch {
                                    try {
                                        val number = withContext(Dispatchers.IO) { fetchCustomerWhatsApp(accessToken, item.optLong("customer_id")) }
                                        if (number.isBlank()) android.widget.Toast.makeText(context, "لا يوجد رقم واتساب أو هاتف مسجل لهذا العميل", android.widget.Toast.LENGTH_LONG).show()
                                        else openWhatsAppChat(context, number)
                                    } catch (e: Exception) {
                                        android.widget.Toast.makeText(context, "تعذر فتح محادثة العميل: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                    }
                                } }) { Text("فتح واتساب العميل", color = Green) }
                            }
                            if (section == "الفواتير" && role == "owner" && item.optString("status") == "approved") {
                                TextButton(onClick = { scope.launch {
                                    try {
                                        val pdfData = withContext(Dispatchers.IO) {
                                            val c = SupabaseData.select("app_customers", accessToken, "select=name&id=eq.${item.optLong("customer_id")}&limit=1")
                                            val li = SupabaseData.select("app_invoice_items", accessToken, "select=piece_id,description,unit_price,line_total&invoice_id=eq.${item.optLong("id")}&order=id.asc")
                                            val invoiceItems = (0 until li.length()).map { li.getJSONObject(it) }
                                            invoiceItems.forEach { line ->
                                                val piece = SupabaseData.select("app_pieces", accessToken, "select=received_from,received_at&id=eq.${line.optLong("piece_id")}&limit=1")
                                                line.put("received_from", if (piece.length() > 0) piece.getJSONObject(0).optString("received_from").takeUnless { it == "null" }.orEmpty() else "")
                                                line.put("received_at", if (piece.length() > 0) piece.getJSONObject(0).optString("received_at").take(10) else "")
                                            }
                                            (if (c.length() > 0) c.getJSONObject(0).optString("name") else "عميل") to invoiceItems
                                        }
                                        shareInvoicePdf(context, item, pdfData.first, pdfData.second)
                                    } catch (e: Exception) { android.widget.Toast.makeText(context, "تعذر تجهيز الفاتورة: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
                                } }) { Text("مشاركة الفاتورة PDF", color = Green) }
                            }
                            if (section == "الفواتير" && role == "owner" && item.optString("status") == "draft") {
                                Text("اعتمد المسودة بعد مراجعتها حتى تتمكن من مشاركة الفاتورة.", color = Muted, fontSize = 11.sp)
                            }
                            if (section == "القطع") {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = {
                                        editingPiece = JSONObject(item.toString())
                                        pieceEditType = item.optString("item_type")
                                        pieceEditPrice = item.optString("price")
                                        pieceEditReceivedFrom = item.optString("received_from").takeUnless { it == "null" }.orEmpty()
                                    }) { Text("تعديل", color = Green) }
                                    if (role == "owner") {
                                        TextButton(onClick = { deletingPiece = JSONObject(item.toString()) }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun OwnerFinanceSection(section: String, accessToken: String) {
    val scope = rememberCoroutineScope()
    val today = remember { LocalDate.now() }
    var fromDate by remember { mutableStateOf(today.withDayOfMonth(1).toString()) }
    var toDate by remember { mutableStateOf(today.toString()) }
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var selectedCustomerId by remember { mutableStateOf("") }
    var customerMenu by remember { mutableStateOf(false) }
    var pieces by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var payments by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var openingPieces by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var openingPayments by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(false) }

    fun amount(list: List<JSONObject>, key: String): java.math.BigDecimal =
        list.fold(java.math.BigDecimal.ZERO) { total, row ->
            total + (row.optString(key).toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO)
        }

    suspend fun loadData() {
        loading = true
        error = null
        try {
            val start = LocalDate.parse(fromDate)
            val end = LocalDate.parse(toDate)
            require(!end.isBefore(start)) { "تاريخ النهاية يجب ألا يسبق تاريخ البداية" }
            val dateFilterPieces = "received_at=gte.${start}T00:00:00&received_at=lte.${end}T23:59:59"
            val dateFilterPayments = "payment_date=gte.${start}T00:00:00&payment_date=lte.${end}T23:59:59"
            val dateFilterExpenses = "expense_date=gte.${start}T00:00:00&expense_date=lte.${end}T23:59:59"
            withContext(Dispatchers.IO) {
                if (section == "سجل المحلات") {
                    val c = SupabaseData.select("app_customers", accessToken, "select=id,name,customer_type&customer_type=eq.shop&order=name.asc&limit=1000")
                    customers = (0 until c.length()).map { c.getJSONObject(it) }
                    if (selectedCustomerId.isBlank() && customers.isNotEmpty()) selectedCustomerId = customers.first().optString("id")
                    if (selectedCustomerId.isNotBlank()) {
                        val pid = java.net.URLEncoder.encode(selectedCustomerId, "UTF-8")
                        val p = SupabaseData.select("app_pieces", accessToken, "select=id,customer_id,received_at,item_type,received_from,description,price,status,paid_immediately&customer_id=eq.$pid&$dateFilterPieces&order=received_at.asc&limit=5000")
                        val pay = SupabaseData.select("app_payments", accessToken, "select=id,customer_id,payment_date,amount,payment_method,reference_number,notes&customer_id=eq.$pid&$dateFilterPayments&order=payment_date.asc&limit=5000")
                        val op = SupabaseData.select("app_pieces", accessToken, "select=id,price,paid_immediately&customer_id=eq.$pid&received_at=lt.${start}T00:00:00&order=received_at.asc&limit=10000")
                        val oy = SupabaseData.select("app_payments", accessToken, "select=id,amount&customer_id=eq.$pid&payment_date=lt.${start}T00:00:00&order=payment_date.asc&limit=10000")
                        pieces = (0 until p.length()).map { p.getJSONObject(it) }
                        payments = (0 until pay.length()).map { pay.getJSONObject(it) }
                        openingPieces = (0 until op.length()).map { op.getJSONObject(it) }
                        openingPayments = (0 until oy.length()).map { oy.getJSONObject(it) }
                    } else {
                        pieces = emptyList(); payments = emptyList(); openingPieces = emptyList(); openingPayments = emptyList()
                    }
                } else {
                    val p = SupabaseData.select("app_pieces", accessToken, "select=id,received_at,item_type,price,status,paid_immediately&$dateFilterPieces&order=received_at.asc&limit=5000")
                    val pay = SupabaseData.select("app_payments", accessToken, "select=id,payment_date,amount&$dateFilterPayments&order=payment_date.asc&limit=5000")
                    val exp = SupabaseData.select("app_expenses", accessToken, "select=id,expense_date,category,description,amount&$dateFilterExpenses&order=expense_date.asc&limit=5000")
                    pieces = (0 until p.length()).map { p.getJSONObject(it) }
                    payments = (0 until pay.length()).map { pay.getJSONObject(it) }
                    expenses = (0 until exp.length()).map { exp.getJSONObject(it) }
                    openingPieces = emptyList(); openingPayments = emptyList()
                }
            }
            loaded = true
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحميل البيانات المالية"
        } finally { loading = false }
    }

    LaunchedEffect(section, accessToken) {
        if (section == "سجل المحلات") {
            try {
                val c = withContext(Dispatchers.IO) { SupabaseData.select("app_customers", accessToken, "select=id,name,customer_type&customer_type=eq.shop&order=name.asc&limit=1000") }
                customers = (0 until c.length()).map { c.getJSONObject(it) }
                if (customers.isNotEmpty() && selectedCustomerId.isBlank()) selectedCustomerId = customers.first().optString("id")
            } catch (e: Exception) { error = e.message ?: "تعذر تحميل العملاء" }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (section == "سجل المحلات") {
            Text("اختيار العميل", color = Green, fontWeight = FontWeight.Bold)
            Box {
                OutlinedButton(onClick = { customerMenu = true }, modifier = Modifier.fillMaxWidth()) {
                    val name = customers.firstOrNull { it.optString("id") == selectedCustomerId }?.optString("name") ?: "اختر العميل"
                    Text(name, color = Green)
                }
                DropdownMenu(expanded = customerMenu, onDismissRequest = { customerMenu = false }) {
                    customers.forEach { c ->
                        DropdownMenuItem(text = { Text(c.optString("name")) }, onClick = { selectedCustomerId = c.optString("id"); loaded = false; customerMenu = false })
                    }
                }
            }
        }
        Text("الفترة الزمنية", color = Green, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = fromDate, onValueChange = { fromDate = it; loaded = false }, label = { Text("تاريخ بداية الفاتورة (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = toDate, onValueChange = { toDate = it; loaded = false }, label = { Text("تاريخ نهاية الفاتورة (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = { scope.launch { loadData() } }, enabled = !loading && (section != "سجل المحلات" || selectedCustomerId.isNotBlank()), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
            if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = White, strokeWidth = 2.dp) else Text(if (section == "سجل المحلات") "عرض كشف الحساب" else "استخراج التقرير", color = White)
        }
        if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        if (loaded && error == null) {
            val piecesTotal = amount(pieces, "price")
            val immediatePaid = pieces.filter { it.optBoolean("paid_immediately") }.fold(java.math.BigDecimal.ZERO) { a, r -> a + (r.optString("price").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO) }
            val paymentsTotal = amount(payments, "amount")
            val paidTotal = immediatePaid + paymentsTotal
            val openingSales = amount(openingPieces, "price")
            val openingImmediate = openingPieces.filter { it.optBoolean("paid_immediately") }.fold(java.math.BigDecimal.ZERO) { a, r -> a + (r.optString("price").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO) }
            val openingBalance = openingSales - openingImmediate - amount(openingPayments, "amount")
            val expensesTotal = amount(expenses, "amount")
            if (section == "سجل المحلات") {
                Text("سجل الأعمال", color = Green, fontWeight = FontWeight.Bold)
                Text("التاريخ • الشغل • اسم مُسلِّم القطعة", color = Muted, fontSize = 12.sp)
                pieces.forEach { r ->
                    FinanceLine("${r.optString("received_at").take(10)} • ${r.optString("item_type")}", r.optString("received_from").takeUnless { it == "null" }.orEmpty().ifBlank { "غير محدد" })
                }
                if (pieces.isEmpty()) Text("لا توجد أعمال مسجلة لهذا المحل خلال الفترة المحددة.", color = Muted)
            } else {
                FinanceMetric("عدد القطع", java.math.BigDecimal(pieces.size))
                FinanceMetric("قيمة الأعمال المسجلة", piecesTotal)
                FinanceMetric("التحصيل الفعلي", paidTotal)
                FinanceMetric("المصروفات", expensesTotal)
                FinanceMetric("صافي حركة النقدية", paymentsTotal + immediatePaid - expensesTotal)
                Text("حالة الأعمال", color = Green, fontWeight = FontWeight.Bold)
                val completed = pieces.count { it.optString("status") == "completed" || it.optString("status") == "delivered" }
                FinanceLine("مكتملة أو تم تسليمها", "$completed من ${pieces.size}")
                Text("المصروفات حسب السجل", color = Green, fontWeight = FontWeight.Bold)
                expenses.forEach { r -> FinanceLine("${r.optString("category")} • ${r.optString("description")}", "${r.optString("amount")} ج.م") }
            }
            Text("الفترة: $fromDate إلى $toDate", color = Muted, fontSize = 11.sp)
        }
    }
}


@Composable
private fun InvoiceDraftForm(accessToken: String, onCancel: () -> Unit, onCreated: () -> Unit) {
    val scope = rememberCoroutineScope()
    val today = remember { LocalDate.now() }
    var invoiceStartDate by remember { mutableStateOf(today.minusDays((today.dayOfWeek.value - 1).toLong()).toString()) }
    var invoiceEndDate by remember { mutableStateOf(today.minusDays((today.dayOfWeek.value - 1).toLong()).plusDays(5).toString()) }
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var pieces by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var selectedCustomer by remember { mutableStateOf("") }
    var customerType by remember { mutableStateOf("private") }
    var customerTypeMenu by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(accessToken) {
        try {
            withContext(Dispatchers.IO) {
                val c = SupabaseData.select("app_customers", accessToken, "select=id,name,customer_type&order=name.asc&limit=1000")
                customers = (0 until c.length()).map { c.getJSONObject(it) }
                val first = customers.firstOrNull { it.optString("customer_type", "private") == customerType }
                if (first != null) selectedCustomer = first.optString("id")
            }
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل العملاء" } finally { loading = false }
    }
    Column(Modifier.fillMaxWidth().background(White, RoundedCornerShape(16.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("إنشاء مسودة فاتورة", color = Green, fontWeight = FontWeight.Bold)
        OutlinedTextField(invoiceStartDate, { invoiceStartDate = it }, label = { Text("تاريخ البداية (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(invoiceEndDate, { invoiceEndDate = it }, label = { Text("تاريخ النهاية (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("اختر أي فترة زمنية تناسبك، بدون قيود أسبوعية.", color = Muted, fontSize = 12.sp)
        Box {
            OutlinedButton(onClick = { customerTypeMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(if (customerType == "shop") "فواتير التجار" else "فواتير الزبائن الخاصين") }
            DropdownMenu(expanded = customerTypeMenu, onDismissRequest = { customerTypeMenu = false }) {
                DropdownMenuItem(text = { Text("الزبائن الخاصون") }, onClick = { customerType = "private"; selectedCustomer = ""; pieces = emptyList(); customerTypeMenu = false })
                DropdownMenuItem(text = { Text("التجار والمحلات") }, onClick = { customerType = "shop"; selectedCustomer = ""; pieces = emptyList(); customerTypeMenu = false })
            }
        }
        val visibleCustomers = customers.filter { it.optString("customer_type", "private") == customerType }
        Box {
            OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                Text(visibleCustomers.firstOrNull { it.optString("id") == selectedCustomer }?.optString("name") ?: "اختيار ${if (customerType == "shop") "التاجر" else "الزبون الخاص"}")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                visibleCustomers.forEach { c -> DropdownMenuItem(text = { Text(c.optString("name")) }, onClick = { selectedCustomer = c.optString("id"); menu = false; pieces = emptyList() }) }
            }
        }
        Button(onClick = { scope.launch {
            loading = true; message = null
            try {
                val start = LocalDate.parse(invoiceStartDate)
                val end = LocalDate.parse(invoiceEndDate)
                require(!end.isBefore(start)) { "تاريخ النهاية يجب ألا يسبق تاريخ البداية" }
                val pid = selectedCustomer.toLong()
                pieces = withContext(Dispatchers.IO) {
                    val all = SupabaseData.select("app_pieces", accessToken, "select=id,customer_id,received_at,item_type,price&customer_id=eq.$pid&received_at=gte.${start}T00:00:00&received_at=lte.${end}T23:59:59&order=received_at.asc&limit=1000")
                    val itemRows = SupabaseData.select("app_invoice_items", accessToken, "select=piece_id,invoice_id&limit=10000")
                    val invoiceRows = SupabaseData.select("app_invoices", accessToken, "select=id,status&limit=10000")
                    val activeInvoiceIds = (0 until invoiceRows.length()).map { invoiceRows.getJSONObject(it) }
                        .filter { it.optString("status") != "void" }
                        .map { it.optLong("id") }.toSet()
                    val invoiced = (0 until itemRows.length()).map { itemRows.getJSONObject(it) }
                        .filter { activeInvoiceIds.contains(it.optLong("invoice_id")) }
                        .map { it.optLong("piece_id") }.toSet()
                    (0 until all.length()).map { all.getJSONObject(it) }.filter { !invoiced.contains(it.optLong("id")) }
                }
                if (pieces.isEmpty()) message = "لا توجد قطع غير مفوترة لهذا العميل خلال الفترة المحددة"
            } catch (e: Exception) { message = e.message ?: "تعذر تحميل القطع" } finally { loading = false }
        } }, enabled = selectedCustomer.isNotBlank() && !loading, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("تحميل القطع غير المفوترة", color = White) }
        if (pieces.isNotEmpty()) {
            val total = pieces.fold(java.math.BigDecimal.ZERO) { a, r -> a + (r.optString("price").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO) }
            Text("${pieces.size} قطعة — الإجمالي ${total.toPlainString()} ج.م", color = Green, fontWeight = FontWeight.Bold)
            pieces.forEach { Text("${it.optString("item_type")} • ${it.optString("price")} ج.م", color = Ink, fontSize = 12.sp) }
            Button(onClick = { saving = true; scope.launch {
                var createdInvoiceId: Long? = null
                try {
                    withContext(Dispatchers.IO) {
                        // invoice_number is generated by PostgreSQL identity; never send it from the client.
                        val invoice = JSONObject().put("customer_id", selectedCustomer.toLong()).put("week_start", invoiceStartDate).put("week_end", invoiceEndDate).put("subtotal", total).put("adjustments", 0).put("total_amount", total).put("status", "draft").put("created_at", java.time.OffsetDateTime.now().toString())
                        val created = SupabaseData.insert("app_invoices", accessToken, invoice)
                        check(created.length() > 0) { "لم يتم إنشاء الفاتورة" }
                        val invoiceId = created.getJSONObject(0).getLong("id")
                        createdInvoiceId = invoiceId
                        pieces.forEach { p ->
                            val price = p.optString("price").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO
                            val inserted = SupabaseData.insert("app_invoice_items", accessToken, JSONObject().put("invoice_id", invoiceId).put("piece_id", p.optLong("id")).put("description", p.optString("item_type")).put("quantity", 1).put("unit_price", price).put("line_total", price).put("created_at", java.time.OffsetDateTime.now().toString()))
                            check(inserted.length() > 0) { "فشل حفظ أحد بنود الفاتورة" }
                        }
                    }
                    onCreated()
                } catch (e: Exception) {
                    // Best-effort rollback. A PostgreSQL RPC transaction is still required for strict atomicity.
                    val rollbackError = try {
                        val id = createdInvoiceId
                        if (id != null) withContext(Dispatchers.IO) {
                            val lines = SupabaseData.select("app_invoice_items", accessToken, "select=id&invoice_id=eq.$id&limit=1000")
                            for (i in 0 until lines.length()) {
                                SupabaseData.delete("app_invoice_items", accessToken, "id=eq.${lines.getJSONObject(i).optLong("id")}")
                            }
                            SupabaseData.delete("app_invoices", accessToken, "id=eq.$id")
                        }
                        null
                    } catch (rollback: Exception) { rollback.message }
                    message = "تعذر إنشاء الفاتورة: ${e.message}" + if (rollbackError != null) " — تعذر التراجع التلقائي: $rollbackError" else " — تم التراجع عن المسودة الجزئية"
                } finally { saving = false }
            } }, enabled = !saving, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                if (saving) CircularProgressIndicator(Modifier.size(18.dp), color = White) else Text("إنشاء مسودة الفاتورة", color = White)
            }
        }
        if (message != null) Text(message!!, color = if (message!!.startsWith("لا توجد")) Muted else MaterialTheme.colorScheme.error, fontSize = 12.sp)
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}

private fun fetchCustomerWhatsApp(accessToken: String, customerId: Long): String {
    val contacts = try {
        SupabaseData.select("app_customer_contacts", accessToken, "select=whatsapp,phone&customer_id=eq.$customerId&order=is_primary.desc&limit=1")
    } catch (_: Exception) {
        SupabaseData.select("app_customer_contacts", accessToken, "select=phone&customer_id=eq.$customerId&order=is_primary.desc&limit=1")
    }
    if (contacts.length() == 0) return ""
    val contact = contacts.getJSONObject(0)
    return contact.optString("whatsapp").takeUnless { it == "null" }.orEmpty()
        .ifBlank { contact.optString("phone").takeUnless { it == "null" }.orEmpty() }
}

private fun openWhatsAppChat(context: android.content.Context, rawNumber: String) {
    val digits = rawNumber.filter { it.isDigit() }
    if (digits.isBlank()) {
        android.widget.Toast.makeText(context, "رقم العميل غير صالح", android.widget.Toast.LENGTH_LONG).show()
        return
    }
    val international = when {
        digits.startsWith("00") -> digits.drop(2)
        digits.startsWith("20") -> digits
        digits.startsWith("0") -> "20" + digits.drop(1)
        else -> digits
    }
    val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$international"))
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        android.widget.Toast.makeText(context, "تعذر فتح واتساب على هذا الجهاز", android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun shareInvoicePdf(context: android.content.Context, invoice: JSONObject, customerName: String, items: List<JSONObject>) {
    try {
        val document = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val title = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 22f
            color = android.graphics.Color.rgb(23, 72, 61)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val normal = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            color = android.graphics.Color.rgb(55, 64, 59)
        }
        val bold = android.graphics.Paint(normal).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }
        val rtl = android.graphics.Paint(normal).apply { textAlign = android.graphics.Paint.Align.RIGHT }
        val rtlBold = android.graphics.Paint(bold).apply { textAlign = android.graphics.Paint.Align.RIGHT }
        val accent = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(197, 166, 106)
            strokeWidth = 2f
        }
        var pageNumber = 0
        var page: PdfDocument.Page? = null
        var canvas: android.graphics.Canvas? = null
        var y = 0f
        fun newPage() {
            if (page != null) document.finishPage(page!!)
            pageNumber++
            page = document.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            canvas = page!!.canvas
            canvas!!.drawText("أشرف أرتين", 555f, 48f, title)
            canvas!!.drawText("فاتورة رقم ${invoice.optString("invoice_number")}", 555f, 80f, title)
            if (pageNumber == 1) {
                canvas!!.drawText("العميل: $customerName", 555f, 116f, rtl)
                canvas!!.drawText("الفترة: ${invoice.optString("week_start")} إلى ${invoice.optString("week_end")}", 555f, 139f, rtl)
            } else canvas!!.drawText("تكملة الفاتورة", 555f, 116f, rtl)
            canvas!!.drawLine(40f, 157f, 555f, 157f, accent)
            canvas!!.drawText("وصف القطعة", 555f, 181f, rtlBold)
            canvas!!.drawText("تاريخ القطعة", 430f, 181f, rtlBold)
            canvas!!.drawText("اسم مُسلِّم القطعة", 270f, 181f, rtlBold)
            canvas!!.drawText("سعر الخدمة", 105f, 181f, rtlBold)
            canvas!!.drawLine(40f, 190f, 555f, 190f, bold)
            y = 216f
        }
        newPage()
        items.forEach { row ->
            if (y > 735f) newPage()
            val description = row.optString("description").take(40)
            val receivedFrom = row.optString("received_from").takeUnless { it == "null" }.orEmpty().ifBlank { "—" }.take(18)
            val pieceDate = row.optString("received_at").ifBlank { "—" }
            val price = row.optString("line_total").ifBlank { row.optString("unit_price") }
            canvas!!.drawText(description, 555f, y, rtl)
            canvas!!.drawText(pieceDate, 430f, y, rtl)
            canvas!!.drawText(receivedFrom, 270f, y, rtl)
            canvas!!.drawText(price, 105f, y, rtl)
            y += 25f
        }
        if (y > 650f) newPage()
        canvas!!.drawLine(40f, y + 8f, 555f, y + 8f, bold)
        canvas!!.drawText("الإجمالي قبل التعديلات: ${invoice.optString("subtotal")} جنيه", 555f, y + 38f, rtlBold)
        canvas!!.drawText("التعديلات: ${invoice.optString("adjustments")} جنيه", 555f, y + 62f, rtl)
        canvas!!.drawText("الإجمالي النهائي: ${invoice.optString("total_amount")} جنيه", 555f, y + 94f, title)
        canvas!!.drawText("الحالة: ${invoice.optString("status")}", 555f, 790f, rtl)
        document.finishPage(page!!)
        val dir = File(context.cacheDir, "shared_invoices").apply { mkdirs() }
        val file = File(dir, "invoice_${invoice.optString("invoice_number")}.pdf")
        file.outputStream().use { document.writeTo(it) }
        document.close()
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "فاتورة أشرف أرتين رقم ${invoice.optString("invoice_number")}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة الفاتورة عبر واتساب أو تطبيق آخر"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "تعذر تجهيز ملف الفاتورة: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun shareWarrantyPdf(context: android.content.Context, customer: JSONObject, piece: JSONObject, warranty: JSONObject) {
    try {
        val document = PdfDocument()
        val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val canvas = page.canvas
        val title = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f
            color = android.graphics.Color.rgb(23, 72, 61)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
        }
        val normal = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 15f
            color = android.graphics.Color.rgb(55, 64, 59)
            textAlign = android.graphics.Paint.Align.RIGHT
        }
        val bold = android.graphics.Paint(normal).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }
        val accent = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(197, 166, 106)
            strokeWidth = 3f
        }
        canvas.drawText("أشرف أرتين", 555f, 60f, title)
        canvas.drawText("شهادة ضمان", 555f, 112f, title)
        canvas.drawText("رقم الشهادة: ${warranty.optString("certificate_number")}", 555f, 154f, bold)
        canvas.drawLine(40f, 177f, 555f, 177f, accent)
        var y = 220f
        fun line(label: String, value: String) {
            canvas.drawText("$label: $value", 555f, y, normal)
            y += 36f
        }
        line("اسم العميل", customer.optString("name").ifBlank { "—" })
        line("رقم الهاتف", customer.optString("whatsapp").ifBlank { customer.optString("phone") }.ifBlank { "—" })
        line("القطعة", piece.optString("item_type").ifBlank { "—" })
        line("الخدمة المشمولة بالضمان", warranty.optString("service_description").ifBlank { "—" })
        val period = warranty.optString("warranty_period").takeUnless { it == "null" }.orEmpty().ifBlank { "غير محددة" }
        line("مدة الضمان", period)
        val validUntil = warranty.optString("valid_until").takeUnless { it == "null" }.orEmpty().ifBlank { "غير محدد" }
        line("تاريخ الانتهاء", validUntil)
        line("تاريخ الإصدار", warranty.optString("issued_at").take(10))
        canvas.drawLine(40f, y + 4f, 555f, y + 4f, accent)
        y += 42f
        canvas.drawText("شروط الضمان", 555f, y, bold); y += 30f
        val terms = listOf(
            "• يغطي هذا الضمان الخدمة المذكورة في الشهادة فقط.",
            "• عند ثبوت خطأ من الورشة، تتم إعادة الخدمة المتأثرة مجانًا.",
            "• التعرض للعطور أو الكريمات أو المواد الكيميائية يستلزم فحص القطعة.",
            "• التعرض الكيميائي لا يلغي الضمان تلقائيًا قبل تحديد سبب التغير."
        )
        terms.forEach { term ->
            canvas.drawText(term, 555f, y, normal)
            y += 42f
        }
        canvas.drawText("نشكركم على ثقتكم في أشرف أرتين", 555f, 760f, bold)
        document.finishPage(page)
        val dir = File(context.cacheDir, "shared_warranties").apply { mkdirs() }
        val certificate = warranty.optString("certificate_number").ifBlank { warranty.optString("id") }
        val file = File(dir, "warranty_$certificate.pdf")
        file.outputStream().use { document.writeTo(it) }
        document.close()
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "شهادة ضمان أشرف أرتين رقم $certificate")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة شهادة الضمان عبر واتساب أو تطبيق آخر"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "تعذر تجهيز شهادة الضمان: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun FinanceMetric(label: String, value: java.math.BigDecimal) {
    Surface(color = White, shape = RoundedCornerShape(14.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Ink, fontWeight = FontWeight.SemiBold)
            Text("${value.setScale(2, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()} ج.م", color = Green, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FinanceLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
