-- Ashraf Artin V7: remove Monday-to-Saturday invoice date restrictions.
-- This changes only the two known date CHECK constraints; it does not delete invoice data.

ALTER TABLE public.app_invoices
    DROP CONSTRAINT IF EXISTS app_invoices_week_start_check;

ALTER TABLE public.app_invoices
    DROP CONSTRAINT IF EXISTS app_invoices_check;

-- Keep week_start/week_end columns for backward compatibility with existing records.
-- V7 stores any valid selected start/end dates in these existing columns.
-- No rows are deleted or rewritten.
