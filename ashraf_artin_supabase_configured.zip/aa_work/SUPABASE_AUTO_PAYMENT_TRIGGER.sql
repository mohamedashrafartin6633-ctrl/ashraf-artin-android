-- Ashraf Artin: automatically record an immediate-paid piece as a customer payment.
-- Run once in Supabase SQL Editor. No client-side employee permission escalation is used.
create or replace function public.record_immediate_piece_payment()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.paid_immediately is true then
    insert into public.app_payments
      (customer_id, amount, payment_date, payment_method, notes,
       idempotency_key, created_by, created_at)
    values
      (new.customer_id, new.price, coalesce(new.received_at, now()),
       'cash', 'تحصيل تلقائي عند تسجيل قطعة مدفوعة فورًا',
       gen_random_uuid(), new.created_by, now());
  end if;
  return new;
end;
$$;

drop trigger if exists trg_record_immediate_piece_payment on public.app_pieces;
create trigger trg_record_immediate_piece_payment
after insert on public.app_pieces
for each row
execute function public.record_immediate_piece_payment();
