package com.ashrafartin.nativeapp

import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Cream = Color(0xFFF7F4EC)
private val White = Color(0xFFFFFFFF)
private val Green = Color(0xFF17483D)
private val Gold = Color(0xFFC5A66A)
private val Ink = Color(0xFF26332E)
private val Muted = Color(0xFF7D817C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.navigationBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { AshrafArtinApp() }
    }
}

@Composable
fun AshrafArtinApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { SecureTokenStore(context) }
    var loggedIn by remember { mutableStateOf(prefs.hasSession()) }
    var accessToken by remember { mutableStateOf(prefs.readSession()?.first.orEmpty()) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Gold, background = Cream, surface = White)) {
        if (loggedIn && accessToken.isNotBlank()) {
            HomeScreen(accessToken = accessToken, onLogout = { prefs.clear(); accessToken = ""; loggedIn = false })
        } else if (loggedIn) {
            LaunchedEffect(Unit) { prefs.clear(); loggedIn = false }
        } else {
            LoginScreen(onLogin = { identifier, password ->
                val result = SupabaseLogin.signIn(identifier, password)
                prefs.save(result.first, result.second)
                accessToken = result.first
                loggedIn = true
            })
        }
    }
}

@Composable
private fun LoginScreen(onLogin: suspend (String, String) -> Unit) {
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().background(Cream).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.brand_logo_card),
            contentDescription = "شعار أشرف أرتين",
            modifier = Modifier.fillMaxWidth().height(190.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(16.dp))
        Text("إدارة الورشة", color = Green, fontSize = 14.sp)
        Spacer(Modifier.height(32.dp))
        Surface(color = White, shape = RoundedCornerShape(22.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("تسجيل الدخول", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = identifier, onValueChange = { identifier = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("اسم المستخدم أو البريد الإلكتروني") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                )
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                Button(
                    onClick = {
                        if (identifier.isBlank() || password.isBlank()) {
                            error = "اكتب اسم المستخدم وكلمة المرور"
                        } else {
                            loading = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { onLogin(identifier.trim(), password) }
                                } catch (e: Exception) {
                                    error = e.message ?: "تعذر تسجيل الدخول، حاول مرة أخرى"
                                } finally { loading = false }
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !loading, colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = White, strokeWidth = 2.dp)
                    else Text("دخول", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Text("بيانات الدخول خاصة بحساب الورشة", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

private object SupabaseLogin {
    fun signIn(identifier: String, password: String): Pair<String, String> {
        require(BuildConfig.SUPABASE_URL.isNotBlank()) { "إعداد SUPABASE_URL غير موجود في بناء التطبيق" }
        require(BuildConfig.SUPABASE_PUBLISHABLE_KEY.isNotBlank()) { "إعداد Publishable Key غير موجود في بناء التطبيق" }
        val endpoint = BuildConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/login-with-username"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        }
        try {
            val body = JSONObject().put("identifier", identifier).put("password", password).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = try { JSONObject(response).optString("error").ifBlank { JSONObject(response).optString("message") } } catch (_: Exception) { "" }
                throw IllegalStateException(message.ifBlank { "فشل تسجيل الدخول (HTTP $code)" })
            }
            val json = JSONObject(response)
            // The Edge Function may return tokens at the root or nested in session/data.session.
            val session = json.optJSONObject("session")
                ?: json.optJSONObject("data")?.optJSONObject("session")
                ?: json.optJSONObject("data")
            val access = firstNonBlank(
                json.optString("access_token"),
                session?.optString("access_token").orEmpty()
            )
            val refresh = firstNonBlank(
                json.optString("refresh_token"),
                session?.optString("refresh_token").orEmpty()
            )
            if (access.isBlank() || refresh.isBlank()) {
                val keys = json.keys().asSequence().toList().joinToString(", ")
                throw IllegalStateException(
                    "استجابة تسجيل الدخول لا تحتوي على access_token و refresh_token. الحقول المستلمة: ${keys.ifBlank { "غير معروفة" }}"
                )
            }
            return access to refresh
        } finally { connection.disconnect() }
    }

    private fun firstNonBlank(vararg values: String): String =
        values.firstOrNull { it.isNotBlank() }.orEmpty()
}

private class SecureTokenStore(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("aa_secure_session", android.content.Context.MODE_PRIVATE)
    fun hasSession(): Boolean = prefs.contains("access") && prefs.contains("refresh")
    fun readSession(): Pair<String, String>? {
        return try {
            val access = prefs.getString("access", null) ?: return null
            val refresh = prefs.getString("refresh", null) ?: return null
            decrypt(access) to decrypt(refresh)
        } catch (_: Exception) {
            clear()
            null
        }
    }
    fun save(access: String, refresh: String) {
        prefs.edit().putString("access", encrypt(access)).putString("refresh", encrypt(refresh)).apply()
    }
    fun clear() { prefs.edit().clear().apply() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("ashraf_artin_session_key", null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder("ashraf_artin_session_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
    private fun decrypt(value: String): String {
        val parts = value.split(":", limit = 2)
        require(parts.size == 2) { "بيانات الجلسة غير صالحة" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }
}

@Composable
private fun HomeScreen(accessToken: String, onLogout: () -> Unit) {
    val tiles = listOf(
        Triple("العملاء", "إدارة بيانات العملاء", Icons.Default.People),
        Triple("القطع", "استلام ومتابعة الأعمال", Icons.Default.Diamond),
        Triple("المدفوعات", "التحصيل والحسابات", Icons.Default.AccountBalanceWallet),
        Triple("الفواتير", "إنشاء ومراجعة الفواتير", Icons.Default.ReceiptLong),
        Triple("الضمان", "كروت الضمان الرقمية", Icons.Default.VerifiedUser),
        Triple("التقارير", "إحصائيات وأداء الورشة", Icons.Default.BarChart)
    )
    var selected by remember { mutableStateOf<String?>(null) }
    if (selected != null) {
        DataSectionScreen(section = selected!!, accessToken = accessToken, onBack = { selected = null })
        return
    }
    Column(
        Modifier.fillMaxSize().background(Cream).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("أهلاً بيك في", color = Muted, fontSize = 13.sp)
                Text("إدارة أشرف أرتين", color = Green, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
            Image(painter = painterResource(id = R.drawable.brand_logo_card), contentDescription = "شعار أشرف أرتين", modifier = Modifier.width(142.dp).height(76.dp), contentScale = ContentScale.Fit)
        }
        Surface(color = Green, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("مرحباً بك", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("إدارة الورشة", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("كل أعمال أشرف أرتين في مكان واحد", color = White.copy(alpha = .88f), fontSize = 12.sp)
                }
                Icon(Icons.Default.Diamond, contentDescription = null, tint = Gold, modifier = Modifier.size(54.dp))
            }
        }
        Text("الخدمات الرئيسية", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        tiles.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                rowItems.forEach { tile ->
                    Surface(onClick = { selected = tile.first }, color = White, shape = RoundedCornerShape(17.dp), shadowElevation = 2.dp, modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(vertical = 17.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Surface(color = Green, shape = RoundedCornerShape(50), modifier = Modifier.size(48.dp)) {
                                Box(contentAlignment = Alignment.Center) { Icon(tile.third, contentDescription = null, tint = Gold, modifier = Modifier.size(27.dp)) }
                            }
                            Text(tile.first, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(tile.second, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
        Surface(color = White, shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Inventory2, contentDescription = null, tint = Green)
                    Spacer(Modifier.width(8.dp))
                    Text("ملخص الورشة", color = Green, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text("اختار أي قسم من الأقسام لعرض بياناته من قاعدة بيانات الورشة.", color = Muted, fontSize = 12.sp)
            }
        }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Text("تسجيل الخروج", color = Green)
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun DataSectionScreen(section: String, accessToken: String, onBack: () -> Unit) {
    val table = when (section) {
        "العملاء" -> "app_customers"
        "القطع" -> "app_pieces"
        "المدفوعات" -> "app_payments"
        "الفواتير" -> "app_invoices"
        else -> null
    }
    var rows by remember(section) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember(section) { mutableStateOf(table != null) }
    var error by remember(section) { mutableStateOf<String?>(null) }
    var showNewPiece by remember { mutableStateOf(false) }
    var customerName by remember { mutableStateOf("") }
    var customerType by remember { mutableStateOf("shop") }
    var customerTypeMenu by remember { mutableStateOf(false) }
    var itemType by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var receivedFrom by remember { mutableStateOf("") }
    var paidImmediately by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun loadRows() {
        val result = withContext(Dispatchers.IO) {
            SupabaseData.select(table!!, accessToken, "select=*&order=id.desc&limit=100")
        }
        rows = (0 until result.length()).map { result.getJSONObject(it) }
    }

    LaunchedEffect(section, accessToken) {
        if (table != null) {
            try {
                if (section == "القطع") {
                    val customerResult = withContext(Dispatchers.IO) {
                        SupabaseData.select("app_customers", accessToken, "select=id,name&order=name.asc&limit=500")
                    }
                    customers = (0 until customerResult.length()).map { customerResult.getJSONObject(it) }
                }
                loadRows()
            } catch (e: Exception) { error = e.message ?: "تعذر تحميل البيانات" }
            finally { loading = false }
        }
    }

    Column(Modifier.fillMaxSize().background(Cream).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع", color = Green) }
            Text(section, color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (section == "القطع" && !showNewPiece) {
            Button(onClick = { showNewPiece = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(14.dp)) {
                Text("+ تسجيل قطعة جديدة", color = White)
            }
        }
        if (section == "القطع" && showNewPiece) {
            Surface(color = White, shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تسجيل قطعة جديدة", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it; saveMessage = null },
                        label = { Text("اسم العميل") },
                        placeholder = { Text("اكتب اسم العميل يدويًا") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Box {
                        OutlinedButton(onClick = { customerTypeMenu = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Text(if (customerType == "shop") "نوع العميل: محل / تاجر" else "نوع العميل: عميل خاص", color = Ink)
                        }
                        DropdownMenu(expanded = customerTypeMenu, onDismissRequest = { customerTypeMenu = false }) {
                            DropdownMenuItem(text = { Text("محل / تاجر") }, onClick = { customerType = "shop"; customerTypeMenu = false })
                            DropdownMenuItem(text = { Text("عميل خاص") }, onClick = { customerType = "private"; customerTypeMenu = false })
                        }
                    }
                    OutlinedTextField(value = itemType, onValueChange = { itemType = it }, label = { Text("نوع القطعة (مثال: خاتم)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("الوصف / اللون / التفاصيل") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    OutlinedTextField(value = price, onValueChange = { price = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("السعر بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(value = receivedFrom, onValueChange = { receivedFrom = it }, label = { Text("اسم الشخص الذي سلّم القطعة (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = paidImmediately, onCheckedChange = { paidImmediately = it })
                        Text("تم الدفع فورًا", color = Ink, fontSize = 14.sp)
                    }
                    if (saveMessage != null) Text(saveMessage!!, color = if (saveMessage!!.startsWith("تم")) Green else MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showNewPiece = false }, modifier = Modifier.weight(1f), enabled = !saving) { Text("إلغاء") }
                        Button(onClick = {
                            val amount = price.toBigDecimalOrNull()
                            when {
                                customerName.isBlank() -> saveMessage = "اكتب اسم العميل أولًا"
                                itemType.isBlank() -> saveMessage = "اكتب نوع القطعة"
                                amount == null || amount < java.math.BigDecimal.ZERO -> saveMessage = "اكتب سعرًا صحيحًا"
                                else -> {
                                    saving = true
                                    saveMessage = null
                                    scope.launch {
                                        try {
                                            val customerId = withContext(Dispatchers.IO) {
                                                val encodedName = java.net.URLEncoder.encode(customerName.trim(), "UTF-8")
                                                val found = SupabaseData.select("app_customers", accessToken, "select=id,name&name=eq.$encodedName&limit=1")
                                                if (found.length() > 0) {
                                                    found.getJSONObject(0).getLong("id")
                                                } else {
                                                    val newCustomer = JSONObject()
                                                        .put("name", customerName.trim())
                                                        .put("customer_type", customerType)
                                                    val created = SupabaseData.insert("app_customers", accessToken, newCustomer)
                                                    check(created.length() > 0) { "لم يتم إنشاء العميل" }
                                                    created.getJSONObject(0).getLong("id")
                                                }
                                            }
                                            val payload = JSONObject()
                                                .put("customer_id", customerId)
                                                .put("item_type", itemType.trim())
                                                .put("description", description.trim().ifBlank { JSONObject.NULL })
                                                .put("price", amount)
                                                .put("received_from", receivedFrom.trim().ifBlank { JSONObject.NULL })
                                                .put("paid_immediately", paidImmediately)
                                                .put("status", "received")
                                            withContext(Dispatchers.IO) { SupabaseData.insert("app_pieces", accessToken, payload) }
                                            loadRows()
                                            showNewPiece = false
                                            customerName = ""
                                            customerType = "shop"
                                            itemType = ""; description = ""; price = ""; receivedFrom = ""; paidImmediately = false
                                            saveMessage = "تم تسجيل القطعة بنجاح"
                                        } catch (e: Exception) { saveMessage = e.message ?: "تعذر حفظ القطعة" }
                                        finally { saving = false }
                                    }
                                }
                            }
                        }, modifier = Modifier.weight(1f), enabled = !saving, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                            if (saving) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = White, strokeWidth = 2.dp) else Text("حفظ القطعة", color = White)
                        }
                    }
                }
            }
        }
        when {
            table == null -> Text(if (section == "الضمان") "قسم الضمان يحتاج تحديد جدول الضمان وطريقة ربطه بالقطع قبل تفعيله." else "التقارير المالية ستُفعّل بعد استكمال صلاحيات المالك وتأمين سياسات قاعدة البيانات.", color = Muted)
            loading -> Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            rows.isEmpty() -> Text("لا توجد سجلات لعرضها حاليًا.", color = Muted)
            else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("آخر ${rows.size} سجل", color = Muted, fontSize = 12.sp)
                rows.forEach { item ->
                    Surface(color = White, shape = RoundedCornerShape(14.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            val title = when (section) {
                                "العملاء" -> item.optString("name")
                                "القطع" -> item.optString("item_type")
                                "المدفوعات" -> "دفعة رقم ${item.optString("id")}" 
                                else -> "فاتورة رقم ${item.optString("invoice_number")}" 
                            }
                            Text(title.ifBlank { "سجل رقم ${item.optString("id")}" }, color = Green, fontWeight = FontWeight.Bold)
                            val detail = when (section) {
                                "العملاء" -> "النوع: ${item.optString("customer_type")}"
                                "القطع" -> "العميل رقم: ${item.optString("customer_id")}  •  الحالة: ${item.optString("status")}  •  السعر: ${item.optString("price")}"
                                "المدفوعات" -> "العميل: ${item.optString("customer_id")}  •  المبلغ: ${item.optString("amount")}"
                                else -> "العميل: ${item.optString("customer_id")}  •  الإجمالي: ${item.optString("total_amount")}  •  الحالة: ${item.optString("status")}"
                            }
                            Text(detail, color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
