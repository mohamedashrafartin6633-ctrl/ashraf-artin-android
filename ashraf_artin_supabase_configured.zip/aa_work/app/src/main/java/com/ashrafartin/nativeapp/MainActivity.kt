package com.ashrafartin.nativeapp

import android.os.Bundle
import android.content.Intent
import android.graphics.pdf.PdfDocument
import java.io.File
import androidx.core.content.FileProvider
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.time.LocalDate
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Cream = Color(0xFFF7F4EC)
private val White = Color(0xFFFFFFFF)
private val Green = Color(0xFF17483D)
private val Gold = Color(0xFFC5A66A)
private val Ink = Color(0xFF26332E)
private val Muted = Color(0xFF7D817C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.navigationBarColor = android.graphics.Color.rgb(247, 244, 236)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { AshrafArtinApp() }
    }
}

@Composable
fun AshrafArtinApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { SecureTokenStore(context) }
    var loggedIn by remember { mutableStateOf(prefs.hasSession()) }
    var accessToken by remember { mutableStateOf(prefs.readSession()?.first.orEmpty()) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Gold, background = Cream, surface = White)) {
        if (loggedIn && accessToken.isNotBlank()) {
            HomeScreen(accessToken = accessToken, onLogout = { prefs.clear(); accessToken = ""; loggedIn = false })
        } else if (loggedIn) {
            LaunchedEffect(Unit) { prefs.clear(); loggedIn = false }
        } else {
            LoginScreen(onLogin = { identifier, password ->
                val result = SupabaseLogin.signIn(identifier, password)
                prefs.save(result.first, result.second)
                accessToken = result.first
                loggedIn = true
            })
        }
    }
}

@Composable
private fun LoginScreen(onLogin: suspend (String, String) -> Unit) {
    var identifier by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(
        Modifier.fillMaxSize().background(Cream).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.brand_logo_card),
            contentDescription = "شعار أشرف أرتين",
            modifier = Modifier.fillMaxWidth().height(190.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(16.dp))
        Text("إدارة الورشة", color = Green, fontSize = 14.sp)
        Spacer(Modifier.height(32.dp))
        Surface(color = White, shape = RoundedCornerShape(22.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("تسجيل الدخول", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = identifier, onValueChange = { identifier = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("اسم المستخدم أو البريد الإلكتروني") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it; error = null },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                )
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                Button(
                    onClick = {
                        if (identifier.isBlank() || password.isBlank()) {
                            error = "اكتب اسم المستخدم وكلمة المرور"
                        } else {
                            loading = true
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { onLogin(identifier.trim(), password) }
                                } catch (e: Exception) {
                                    error = e.message ?: "تعذر تسجيل الدخول، حاول مرة أخرى"
                                } finally { loading = false }
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !loading, colors = ButtonDefaults.buttonColors(containerColor = Green),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = White, strokeWidth = 2.dp)
                    else Text("دخول", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Text("بيانات الدخول خاصة بحساب الورشة", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

private object SupabaseLogin {
    fun signIn(identifier: String, password: String): Pair<String, String> {
        require(BuildConfig.SUPABASE_URL.isNotBlank()) { "إعداد SUPABASE_URL غير موجود في بناء التطبيق" }
        require(BuildConfig.SUPABASE_PUBLISHABLE_KEY.isNotBlank()) { "إعداد Publishable Key غير موجود في بناء التطبيق" }
        val endpoint = BuildConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/login-with-username"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        }
        try {
            val body = JSONObject().put("identifier", identifier).put("password", password).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = try { JSONObject(response).optString("error").ifBlank { JSONObject(response).optString("message") } } catch (_: Exception) { "" }
                throw IllegalStateException(message.ifBlank { "فشل تسجيل الدخول (HTTP $code)" })
            }
            val json = JSONObject(response)
            // The Edge Function may return tokens at the root or nested in session/data.session.
            val session = json.optJSONObject("session")
                ?: json.optJSONObject("data")?.optJSONObject("session")
                ?: json.optJSONObject("data")
            val access = firstNonBlank(
                json.optString("access_token"),
                session?.optString("access_token").orEmpty()
            )
            val refresh = firstNonBlank(
                json.optString("refresh_token"),
                session?.optString("refresh_token").orEmpty()
            )
            if (access.isBlank() || refresh.isBlank()) {
                val keys = json.keys().asSequence().toList().joinToString(", ")
                throw IllegalStateException(
                    "استجابة تسجيل الدخول لا تحتوي على access_token و refresh_token. الحقول المستلمة: ${keys.ifBlank { "غير معروفة" }}"
                )
            }
            return access to refresh
        } finally { connection.disconnect() }
    }

    private fun firstNonBlank(vararg values: String): String =
        values.firstOrNull { it.isNotBlank() }.orEmpty()
}

private class SecureTokenStore(context: android.content.Context) {
    private val prefs = context.getSharedPreferences("aa_secure_session", android.content.Context.MODE_PRIVATE)
    fun hasSession(): Boolean = prefs.contains("access") && prefs.contains("refresh")
    fun readSession(): Pair<String, String>? {
        return try {
            val access = prefs.getString("access", null) ?: return null
            val refresh = prefs.getString("refresh", null) ?: return null
            decrypt(access) to decrypt(refresh)
        } catch (_: Exception) {
            clear()
            null
        }
    }
    fun save(access: String, refresh: String) {
        prefs.edit().putString("access", encrypt(access)).putString("refresh", encrypt(refresh)).apply()
    }
    fun clear() { prefs.edit().clear().apply() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("ashraf_artin_session_key", null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder("ashraf_artin_session_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
    private fun decrypt(value: String): String {
        val parts = value.split(":", limit = 2)
        require(parts.size == 2) { "بيانات الجلسة غير صالحة" }
        val iv = Base64.decode(parts[0], Base64.NO_WRAP)
        val encrypted = Base64.decode(parts[1], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }

    private fun encrypt(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }
}

@Composable
private fun HomeScreen(accessToken: String, onLogout: () -> Unit) {
    var role by remember(accessToken) { mutableStateOf<String?>(null) }
    var profileLoading by remember(accessToken) { mutableStateOf(true) }
    var profileError by remember(accessToken) { mutableStateOf<String?>(null) }
    LaunchedEffect(accessToken) {
        profileLoading = true
        profileError = null
        try {
            role = withContext(Dispatchers.IO) {
                val user = SupabaseData.currentUser(accessToken)
                SupabaseData.profile(user.getString("id"), accessToken).getString("role")
            }
        } catch (e: Exception) {
            profileError = e.message ?: "تعذر التحقق من صلاحيات الحساب"
        } finally { profileLoading = false }
    }

    val ownerTiles = listOf(
        Triple("العملاء", "إدارة بيانات العملاء", Icons.Default.People),
        Triple("القطع", "استلام ومتابعة الأعمال", Icons.Default.Diamond),
        Triple("المدفوعات", "التحصيل والحسابات", Icons.Default.AccountBalanceWallet),
        Triple("المصروفات", "مصروفات الورشة", Icons.Default.AccountBalanceWallet),
        Triple("الفواتير", "إنشاء ومراجعة الفواتير", Icons.Default.ReceiptLong),
        Triple("كشوف الحساب", "حساب كل عميل والمدفوع والمتبقي", Icons.Default.AccountBalanceWallet),
        Triple("الضمان", "كروت الضمان الرقمية", Icons.Default.VerifiedUser),
        Triple("التقارير", "إحصائيات وأداء الورشة", Icons.Default.BarChart)
    )
    val employeeTiles = listOf(
        Triple("العملاء", "إدارة بيانات العملاء", Icons.Default.People),
        Triple("القطع", "استلام ومتابعة الأعمال", Icons.Default.Diamond),
        Triple("الضمان", "متابعة الضمان", Icons.Default.VerifiedUser)
    )
    val tiles = when (role) {
        "owner" -> ownerTiles
        "employee" -> employeeTiles
        else -> emptyList()
    }
    var selected by remember { mutableStateOf<String?>(null) }
    if (selected != null) {
        DataSectionScreen(section = selected!!, accessToken = accessToken, role = role.orEmpty(), onBack = { selected = null })
        return
    }
    Column(
        Modifier.fillMaxSize().background(Cream).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("أهلاً بيك في", color = Muted, fontSize = 13.sp)
                Text("إدارة أشرف أرتين", color = Green, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
            Image(painter = painterResource(id = R.drawable.brand_logo_card), contentDescription = "شعار أشرف أرتين", modifier = Modifier.width(142.dp).height(76.dp), contentScale = ContentScale.Fit)
        }
        Surface(color = Green, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("مرحباً بك", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("إدارة الورشة", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("كل أعمال أشرف أرتين في مكان واحد", color = White.copy(alpha = .88f), fontSize = 12.sp)
                }
                Icon(Icons.Default.Diamond, contentDescription = null, tint = Gold, modifier = Modifier.size(54.dp))
            }
        }
        if (profileLoading) {
            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
        } else if (profileError != null) {
            Text(profileError!!, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            Text("تم إيقاف عرض الأقسام لحين التحقق من صلاحية الحساب.", color = Muted, fontSize = 12.sp)
        } else {
            Text(if (role == "owner") "حساب المالك — صلاحيات كاملة" else "حساب الموظف — صلاحيات تشغيلية", color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("الخدمات الرئيسية", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            tiles.chunked(2).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    rowItems.forEach { tile ->
                        Surface(onClick = { selected = tile.first }, color = White, shape = RoundedCornerShape(17.dp), shadowElevation = 2.dp, modifier = Modifier.weight(1f)) {
                            Column(Modifier.padding(vertical = 17.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Surface(color = Green, shape = RoundedCornerShape(50), modifier = Modifier.size(48.dp)) {
                                    Box(contentAlignment = Alignment.Center) { Icon(tile.third, contentDescription = null, tint = Gold, modifier = Modifier.size(27.dp)) }
                                }
                                Text(tile.first, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text(tile.second, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        Surface(color = White, shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Inventory2, contentDescription = null, tint = Green)
                    Spacer(Modifier.width(8.dp))
                    Text("ملخص الورشة", color = Green, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text("${if (role == "employee") "متابعة العملاء والقطع وحالة العمل." else "إدارة ومتابعة أعمال الورشة وحساباتها."}", color = Muted, fontSize = 12.sp)
            }
        }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Text("تسجيل الخروج", color = Green)
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun DataSectionScreen(section: String, accessToken: String, role: String, onBack: () -> Unit) {
    val allowed = role == "owner" || (role == "employee" && section in setOf("العملاء", "القطع", "الضمان"))
    val table = when (section) {
        "العملاء" -> "app_customers"
        "القطع" -> "app_pieces"
        "المدفوعات" -> "app_payments"
        "المصروفات" -> "app_expenses"
        "الفواتير" -> "app_invoices"
        else -> null
    }
    var rows by remember(section) { mutableStateOf<List<JSONObject>>(emptyList()) }
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember(section) { mutableStateOf(table != null) }
    var error by remember(section) { mutableStateOf<String?>(null) }
    var showNewPiece by remember { mutableStateOf(false) }
    var editingCustomer by remember { mutableStateOf<JSONObject?>(null) }
    var customerEditName by remember { mutableStateOf("") }
    var customerEditType by remember { mutableStateOf("shop") }
    var customerEditAddress by remember { mutableStateOf("") }
    var customerEditNotes by remember { mutableStateOf("") }
    var showNewExpense by remember { mutableStateOf(false) }
    var expenseCategory by remember { mutableStateOf("") }
    var expenseDescription by remember { mutableStateOf("") }
    var expenseAmount by remember { mutableStateOf("") }
    var expensePaidTo by remember { mutableStateOf("") }
    var expenseNotes by remember { mutableStateOf("") }
    var showNewInvoice by remember { mutableStateOf(false) }
    var customerName by remember { mutableStateOf("") }
    var customerType by remember { mutableStateOf("shop") }
    var customerTypeMenu by remember { mutableStateOf(false) }
    var itemType by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var receivedFrom by remember { mutableStateOf("") }
    var paidImmediately by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    suspend fun loadRows() {
        val result = withContext(Dispatchers.IO) {
            SupabaseData.select(table!!, accessToken, "select=*&order=id.desc&limit=100")
        }
        rows = (0 until result.length()).map { result.getJSONObject(it) }
    }

    LaunchedEffect(section, accessToken) {
        if (table != null) {
            try {
                if (section == "القطع") {
                    val customerResult = withContext(Dispatchers.IO) {
                        SupabaseData.select("app_customers", accessToken, "select=id,name&order=name.asc&limit=500")
                    }
                    customers = (0 until customerResult.length()).map { customerResult.getJSONObject(it) }
                }
                loadRows()
            } catch (e: Exception) { error = e.message ?: "تعذر تحميل البيانات" }
            finally { loading = false }
        }
    }

    Column(Modifier.fillMaxSize().background(Cream).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع", color = Green) }
            Text(section, color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (!allowed || (role !in setOf("owner", "employee"))) {
            Text("غير مسموح لهذا الحساب بفتح القسم.", color = MaterialTheme.colorScheme.error)
            return@Column
        }
        if (section == "كشوف الحساب" || section == "التقارير") {
            if (role != "owner") {
                Text("هذا القسم متاح للمالك فقط.", color = MaterialTheme.colorScheme.error)
            } else {
                OwnerFinanceSection(section = section, accessToken = accessToken)
            }
            return@Column
        }
        if (section == "القطع" && !showNewPiece) {
            Button(onClick = { showNewPiece = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(14.dp)) {
                Text("+ تسجيل قطعة جديدة", color = White)
            }
        }
        if (section == "المصروفات" && !showNewExpense) {
            Button(onClick = { showNewExpense = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("+ تسجيل مصروف", color = White) }
        }
        if (section == "الفواتير" && !showNewInvoice) {
            Button(onClick = { showNewInvoice = true; saveMessage = null }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("+ إنشاء فاتورة أسبوعية", color = White) }
        }
        if (section == "العملاء") {
            Text("إدارة بيانات العملاء", color = Green, fontWeight = FontWeight.Bold)
        }
        if (section == "المصروفات" && showNewExpense) {
            Surface(color = White, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مصروف جديد", color = Green, fontWeight = FontWeight.Bold)
                    OutlinedTextField(expenseCategory, { expenseCategory = it }, label = { Text("تصنيف المصروف") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expenseDescription, { expenseDescription = it }, label = { Text("وصف المصروف") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expenseAmount, { expenseAmount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("المبلغ بالجنيه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expensePaidTo, { expensePaidTo = it }, label = { Text("صُرف إلى (اختياري)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(expenseNotes, { expenseNotes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showNewExpense = false }, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                        Button(onClick = {
                            val v = expenseAmount.toBigDecimalOrNull()
                            if (expenseCategory.isBlank() || expenseDescription.isBlank() || v == null || v <= java.math.BigDecimal.ZERO) saveMessage = "أكمل التصنيف والوصف واكتب مبلغًا صحيحًا أكبر من صفر"
                            else { saving = true; scope.launch { try {
                                val payload = JSONObject().put("expense_date", java.time.OffsetDateTime.now().toString()).put("category", expenseCategory.trim()).put("description", expenseDescription.trim()).put("amount", v).put("paid_to", expensePaidTo.trim().ifBlank { JSONObject.NULL }).put("notes", expenseNotes.trim().ifBlank { JSONObject.NULL }).put("idempotency_key", java.util.UUID.randomUUID().toString()).put("created_at", java.time.OffsetDateTime.now().toString())
                                withContext(Dispatchers.IO) { SupabaseData.insert("app_expenses", accessToken, payload) }; loadRows(); showNewExpense = false; expenseCategory = ""; expenseDescription = ""; expenseAmount = ""; expensePaidTo = ""; expenseNotes = ""; saveMessage = "تم تسجيل المصروف"
                            } catch(e: Exception) { saveMessage = e.message ?: "تعذر تسجيل المصروف" } finally { saving = false } } }
                        }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("حفظ المصروف", color = White) }
                    }
                    if (saveMessage != null) Text(saveMessage!!, color = Green)
                }
            }
        }
        if (section == "الفواتير" && showNewInvoice) {
            InvoiceDraftForm(accessToken = accessToken, onCancel = { showNewInvoice = false }, onCreated = { scope.launch { loadRows(); showNewInvoice = false; saveMessage = "تم إنشاء مسودة الفاتورة" } })
        }
        if (section == "القطع" && showNewPiece) {
            Surface(color = White, shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("تسجيل قطعة جديدة", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it; saveMessage = null },
                        label = { Text("اسم العميل") },
                        placeholder = { Text("اكتب اسم العميل يدويًا") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Box {
                        OutlinedButton(onClick = { customerTypeMenu = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                            Text(if (customerType == "shop") "نوع العميل: محل / تاجر" else "نوع العميل: عميل خاص", color = Ink)
                        }
                        DropdownMenu(expanded = customerTypeMenu, onDismissRequest = { customerTypeMenu = false }) {
                            DropdownMenuItem(text = { Text("محل / تاجر") }, onClick = { customerType = "shop"; customerTypeMenu = false })
                            DropdownMenuItem(text = { Text("عميل خاص") }, onClick = { customerType = "private"; customerTypeMenu = false })
                        }
                    }
                    OutlinedTextField(value = itemType, onValueChange = { itemType = it }, label = { Text("نوع القطعة (مثال: خاتم)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("الوصف / اللون / التفاصيل") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    OutlinedTextField(value = price, onValueChange = { price = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("السعر بالجنيه") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(value = receivedFrom, onValueChange = { receivedFrom = it }, label = { Text("اسم الشخص الذي سلّم القطعة (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = paidImmediately, onCheckedChange = { paidImmediately = it })
                        Text("تم الدفع فورًا", color = Ink, fontSize = 14.sp)
                    }
                    if (saveMessage != null) Text(saveMessage!!, color = if (saveMessage!!.startsWith("تم")) Green else MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showNewPiece = false }, modifier = Modifier.weight(1f), enabled = !saving) { Text("إلغاء") }
                        Button(onClick = {
                            val amount = price.toBigDecimalOrNull()
                            when {
                                customerName.isBlank() -> saveMessage = "اكتب اسم العميل أولًا"
                                itemType.isBlank() -> saveMessage = "اكتب نوع القطعة"
                                amount == null || amount < java.math.BigDecimal.ZERO -> saveMessage = "اكتب سعرًا صحيحًا"
                                else -> {
                                    saving = true
                                    saveMessage = null
                                    scope.launch {
                                        try {
                                            val customerId = withContext(Dispatchers.IO) {
                                                val encodedName = java.net.URLEncoder.encode(customerName.trim(), "UTF-8")
                                                val found = SupabaseData.select("app_customers", accessToken, "select=id,name&name=eq.$encodedName&limit=1")
                                                if (found.length() > 0) {
                                                    found.getJSONObject(0).getLong("id")
                                                } else {
                                                    val newCustomer = JSONObject()
                                                        .put("name", customerName.trim())
                                                        .put("customer_type", customerType)
                                                    val created = SupabaseData.insert("app_customers", accessToken, newCustomer)
                                                    check(created.length() > 0) { "لم يتم إنشاء العميل" }
                                                    created.getJSONObject(0).getLong("id")
                                                }
                                            }
                                            val payload = JSONObject()
                                                .put("customer_id", customerId)
                                                .put("item_type", itemType.trim())
                                                .put("description", description.trim().ifBlank { JSONObject.NULL })
                                                .put("price", amount)
                                                .put("received_from", receivedFrom.trim().ifBlank { JSONObject.NULL })
                                                .put("paid_immediately", paidImmediately)
                                                .put("status", "received")
                                            withContext(Dispatchers.IO) { SupabaseData.insert("app_pieces", accessToken, payload) }
                                            loadRows()
                                            showNewPiece = false
                                            customerName = ""
                                            customerType = "shop"
                                            itemType = ""; description = ""; price = ""; receivedFrom = ""; paidImmediately = false
                                            saveMessage = "تم تسجيل القطعة بنجاح"
                                        } catch (e: Exception) { saveMessage = e.message ?: "تعذر حفظ القطعة" }
                                        finally { saving = false }
                                    }
                                }
                            }
                        }, modifier = Modifier.weight(1f), enabled = !saving, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                            if (saving) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = White, strokeWidth = 2.dp) else Text("حفظ القطعة", color = White)
                        }
                    }
                }
            }
        }
        if (editingCustomer != null) {
            AlertDialog(onDismissRequest = { editingCustomer = null }, title = { Text("تعديل بيانات العميل", color = Green) },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(customerEditName, { customerEditName = it }, label = { Text("اسم العميل") })
                    OutlinedTextField(customerEditAddress, { customerEditAddress = it }, label = { Text("العنوان") })
                    OutlinedTextField(customerEditNotes, { customerEditNotes = it }, label = { Text("ملاحظات") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("نوع العميل", color = Ink)
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { customerEditType = if (customerEditType == "shop") "private" else "shop" }) { Text(if (customerEditType == "shop") "محل / تاجر" else "عميل خاص") }
                    }
                } }, confirmButton = { TextButton(onClick = {
                    val target = editingCustomer ?: return@TextButton
                    if (customerEditName.isBlank()) { saveMessage = "اسم العميل مطلوب" } else {
                        saving = true; scope.launch { try {
                            withContext(Dispatchers.IO) { SupabaseData.update("app_customers", accessToken, "id=eq.${target.optLong("id")}", JSONObject().put("name", customerEditName.trim()).put("customer_type", customerEditType).put("address", customerEditAddress.trim().ifBlank { JSONObject.NULL }).put("notes", customerEditNotes.trim().ifBlank { JSONObject.NULL }).put("updated_at", java.time.OffsetDateTime.now().toString())) }
                            loadRows(); editingCustomer = null; saveMessage = "تم تحديث بيانات العميل"
                        } catch(e: Exception) { saveMessage = e.message ?: "تعذر تعديل العميل" } finally { saving = false } }
                    }
                }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { editingCustomer = null }) { Text("إلغاء") } })
        }
        when {
            table == null -> Text(if (section == "الضمان") "قسم الضمان يحتاج اعتماد جدول مستقل قبل تفعيله." else "هذا القسم لم يتم توصيل عملياته بعد.", color = Muted)
            loading -> Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Green) }
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            rows.isEmpty() -> Text("لا توجد سجلات لعرضها حاليًا.", color = Muted)
            else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("آخر ${rows.size} سجل", color = Muted, fontSize = 12.sp)
                rows.forEach { item ->
                    Surface(color = White, shape = RoundedCornerShape(14.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            val title = when (section) {
                                "العملاء" -> item.optString("name")
                                "القطع" -> item.optString("item_type")
                                "المدفوعات" -> "دفعة رقم ${item.optString("id")}" 
                                else -> "فاتورة رقم ${item.optString("invoice_number")}" 
                            }
                            Text(title.ifBlank { "سجل رقم ${item.optString("id")}" }, color = Green, fontWeight = FontWeight.Bold)
                            val detail = when (section) {
                                "العملاء" -> "النوع: ${item.optString("customer_type")}"
                                "القطع" -> "العميل رقم: ${item.optString("customer_id")}  •  الحالة: ${item.optString("status")}  •  السعر: ${item.optString("price")}"
                                "المدفوعات" -> "العميل: ${item.optString("customer_id")}  •  المبلغ: ${item.optString("amount")}"
                                else -> "العميل: ${item.optString("customer_id")}  •  الإجمالي: ${item.optString("total_amount")}  •  الحالة: ${item.optString("status")}"
                            }
                            Text(detail, color = Muted, fontSize = 12.sp)
                            if (section == "العملاء") {
                                TextButton(onClick = { editingCustomer = JSONObject(item.toString()); customerEditName = item.optString("name"); customerEditType = item.optString("customer_type", "shop"); customerEditAddress = item.optString("address").takeUnless { it == "null" }.orEmpty(); customerEditNotes = item.optString("notes").takeUnless { it == "null" }.orEmpty() }) { Text("تعديل بيانات العميل", color = Green) }
                            }
                            if (section == "الفواتير" && role == "owner" && item.optString("status") == "draft") {
                                TextButton(onClick = { scope.launch {
                                    try {
                                        withContext(Dispatchers.IO) {
                                            val user = SupabaseData.currentUser(accessToken)
                                            SupabaseData.update("app_invoices", accessToken, "id=eq.${item.optLong("id")}", JSONObject().put("status", "approved").put("approved_at", java.time.OffsetDateTime.now().toString()).put("approved_by", user.getString("id")))
                                        }
                                        loadRows(); saveMessage = "تم اعتماد الفاتورة"
                                    } catch (e: Exception) { saveMessage = "تعذر اعتماد الفاتورة: ${e.message}" }
                                } }) { Text("اعتماد الفاتورة", color = Green) }
                            }
                            if (section == "الفواتير" && role == "owner") {
                                TextButton(onClick = { scope.launch {
                                    try {
                                        val pdfData = withContext(Dispatchers.IO) {
                                            val c = SupabaseData.select("app_customers", accessToken, "select=name&id=eq.${item.optLong("customer_id")}&limit=1")
                                            val li = SupabaseData.select("app_invoice_items", accessToken, "select=description,quantity,unit_price,line_total&invoice_id=eq.${item.optLong("id")}&order=id.asc")
                                            (if (c.length() > 0) c.getJSONObject(0).optString("name") else "عميل") to (0 until li.length()).map { li.getJSONObject(it) }
                                        }
                                        shareInvoicePdf(context, item, pdfData.first, pdfData.second)
                                    } catch (e: Exception) { android.widget.Toast.makeText(context, "تعذر تجهيز الفاتورة: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
                                } }) { Text("مشاركة الفاتورة PDF", color = Green) }
                            }
                            if (section == "القطع") {
                                Spacer(Modifier.height(6.dp))
                                PieceStatusControl(
                                    pieceId = item.optLong("id"),
                                    currentStatus = item.optString("status", "received"),
                                    accessToken = accessToken,
                                    enabled = role == "owner" || role == "employee",
                                    onUpdated = { newStatus ->
                                        rows = rows.map { row ->
                                            if (row.optLong("id") == item.optLong("id")) JSONObject(row.toString()).put("status", newStatus) else row
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun PieceStatusControl(
    pieceId: Long,
    currentStatus: String,
    accessToken: String,
    enabled: Boolean,
    onUpdated: (String) -> Unit
) {
    val labels = linkedMapOf(
        "received" to "تم الاستلام",
        "in_progress" to "قيد التنفيذ",
        "completed" to "مكتملة",
        "delivered" to "تم التسليم"
    )
    var expanded by remember(pieceId) { mutableStateOf(false) }
    var saving by remember(pieceId) { mutableStateOf(false) }
    var message by remember(pieceId) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("تحديث الحالة:", color = Muted, fontSize = 12.sp)
        Box {
            OutlinedButton(
                onClick = { expanded = true },
                enabled = enabled && !saving,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
                if (saving) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                else Text(labels[currentStatus] ?: currentStatus, color = Green, fontSize = 12.sp)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                labels.forEach { (value, label) ->
                    DropdownMenuItem(
                        text = { Text(label) },
                        enabled = value != currentStatus && !saving,
                        onClick = {
                            expanded = false
                            saving = true
                            message = null
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) {
                                        SupabaseData.update(
                                            "app_pieces", accessToken, "id=eq.$pieceId",
                                            JSONObject().put("status", value)
                                        )
                                    }
                                    onUpdated(value)
                                    message = "تم تحديث الحالة"
                                } catch (e: Exception) {
                                    message = e.message ?: "تعذر تحديث الحالة"
                                } finally { saving = false }
                            }
                        }
                    )
                }
            }
        }
    }
    if (message != null) {
        Text(message!!, color = if (message == "تم تحديث الحالة") Green else MaterialTheme.colorScheme.error, fontSize = 11.sp)
    }
}


@Composable
private fun OwnerFinanceSection(section: String, accessToken: String) {
    val scope = rememberCoroutineScope()
    val today = remember { LocalDate.now() }
    var fromDate by remember { mutableStateOf(today.withDayOfMonth(1).toString()) }
    var toDate by remember { mutableStateOf(today.toString()) }
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var selectedCustomerId by remember { mutableStateOf("") }
    var customerMenu by remember { mutableStateOf(false) }
    var pieces by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var payments by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(false) }

    fun amount(list: List<JSONObject>, key: String): java.math.BigDecimal =
        list.fold(java.math.BigDecimal.ZERO) { total, row ->
            total + (row.optString(key).toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO)
        }

    suspend fun loadData() {
        loading = true
        error = null
        try {
            val start = LocalDate.parse(fromDate)
            val end = LocalDate.parse(toDate)
            require(!end.isBefore(start)) { "تاريخ النهاية يجب ألا يسبق تاريخ البداية" }
            val dateFilterPieces = "received_at=gte.${start}T00:00:00&received_at=lte.${end}T23:59:59"
            val dateFilterPayments = "payment_date=gte.${start}T00:00:00&payment_date=lte.${end}T23:59:59"
            val dateFilterExpenses = "expense_date=gte.${start}T00:00:00&expense_date=lte.${end}T23:59:59"
            withContext(Dispatchers.IO) {
                if (section == "كشوف الحساب") {
                    val c = SupabaseData.select("app_customers", accessToken, "select=id,name,customer_type&order=name.asc&limit=1000")
                    customers = (0 until c.length()).map { c.getJSONObject(it) }
                    if (selectedCustomerId.isBlank() && customers.isNotEmpty()) selectedCustomerId = customers.first().optString("id")
                    if (selectedCustomerId.isNotBlank()) {
                        val pid = java.net.URLEncoder.encode(selectedCustomerId, "UTF-8")
                        val p = SupabaseData.select("app_pieces", accessToken, "select=id,customer_id,received_at,item_type,description,price,status,paid_immediately&customer_id=eq.$pid&$dateFilterPieces&order=received_at.asc&limit=5000")
                        val pay = SupabaseData.select("app_payments", accessToken, "select=id,customer_id,payment_date,amount,payment_method,reference_number,notes&customer_id=eq.$pid&$dateFilterPayments&order=payment_date.asc&limit=5000")
                        pieces = (0 until p.length()).map { p.getJSONObject(it) }
                        payments = (0 until pay.length()).map { pay.getJSONObject(it) }
                    } else {
                        pieces = emptyList(); payments = emptyList()
                    }
                } else {
                    val p = SupabaseData.select("app_pieces", accessToken, "select=id,received_at,item_type,price,status,paid_immediately&$dateFilterPieces&order=received_at.asc&limit=5000")
                    val pay = SupabaseData.select("app_payments", accessToken, "select=id,payment_date,amount&$dateFilterPayments&order=payment_date.asc&limit=5000")
                    val exp = SupabaseData.select("app_expenses", accessToken, "select=id,expense_date,category,description,amount&$dateFilterExpenses&order=expense_date.asc&limit=5000")
                    pieces = (0 until p.length()).map { p.getJSONObject(it) }
                    payments = (0 until pay.length()).map { pay.getJSONObject(it) }
                    expenses = (0 until exp.length()).map { exp.getJSONObject(it) }
                }
            }
            loaded = true
        } catch (e: Exception) {
            error = e.message ?: "تعذر تحميل البيانات المالية"
        } finally { loading = false }
    }

    LaunchedEffect(section, accessToken) {
        if (section == "كشوف الحساب") {
            try {
                val c = withContext(Dispatchers.IO) { SupabaseData.select("app_customers", accessToken, "select=id,name,customer_type&order=name.asc&limit=1000") }
                customers = (0 until c.length()).map { c.getJSONObject(it) }
                if (customers.isNotEmpty() && selectedCustomerId.isBlank()) selectedCustomerId = customers.first().optString("id")
            } catch (e: Exception) { error = e.message ?: "تعذر تحميل العملاء" }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (section == "كشوف الحساب") {
            Text("اختيار العميل", color = Green, fontWeight = FontWeight.Bold)
            Box {
                OutlinedButton(onClick = { customerMenu = true }, modifier = Modifier.fillMaxWidth()) {
                    val name = customers.firstOrNull { it.optString("id") == selectedCustomerId }?.optString("name") ?: "اختر العميل"
                    Text(name, color = Green)
                }
                DropdownMenu(expanded = customerMenu, onDismissRequest = { customerMenu = false }) {
                    customers.forEach { c ->
                        DropdownMenuItem(text = { Text(c.optString("name")) }, onClick = { selectedCustomerId = c.optString("id"); loaded = false; customerMenu = false })
                    }
                }
            }
        }
        Text("الفترة الزمنية", color = Green, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = fromDate, onValueChange = { fromDate = it; loaded = false }, label = { Text("من تاريخ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = toDate, onValueChange = { toDate = it; loaded = false }, label = { Text("إلى تاريخ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Button(onClick = { scope.launch { loadData() } }, enabled = !loading && (section != "كشوف الحساب" || selectedCustomerId.isNotBlank()), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
            if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = White, strokeWidth = 2.dp) else Text(if (section == "كشوف الحساب") "عرض كشف الحساب" else "استخراج التقرير", color = White)
        }
        if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        if (loaded && error == null) {
            val piecesTotal = amount(pieces, "price")
            val immediatePaid = pieces.filter { it.optBoolean("paid_immediately") }.fold(java.math.BigDecimal.ZERO) { a, r -> a + (r.optString("price").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO) }
            val paymentsTotal = amount(payments, "amount")
            val paidTotal = immediatePaid + paymentsTotal
            val expensesTotal = amount(expenses, "amount")
            if (section == "كشوف الحساب") {
                val due = piecesTotal - paidTotal
                FinanceMetric("إجمالي قيمة القطع", piecesTotal)
                FinanceMetric("إجمالي المدفوع", paidTotal)
                FinanceMetric("المتبقي على العميل", due)
                Text("تفاصيل القطع", color = Green, fontWeight = FontWeight.Bold)
                pieces.forEach { r ->
                    FinanceLine("${r.optString("item_type")} • ${r.optString("received_at").take(10)}", "${r.optString("price")} ج.م")
                }
                Text("تفاصيل المدفوعات", color = Green, fontWeight = FontWeight.Bold)
                payments.forEach { r ->
                    FinanceLine("${r.optString("payment_date").take(10)} • ${r.optString("payment_method")}", "${r.optString("amount")} ج.م")
                }
                if (pieces.isEmpty() && payments.isEmpty()) Text("لا توجد حركة لهذا العميل في الفترة المحددة.", color = Muted)
            } else {
                FinanceMetric("عدد القطع", java.math.BigDecimal(pieces.size))
                FinanceMetric("قيمة الأعمال المسجلة", piecesTotal)
                FinanceMetric("التحصيل الفعلي", paidTotal)
                FinanceMetric("المصروفات", expensesTotal)
                FinanceMetric("صافي حركة النقدية", paymentsTotal - expensesTotal)
                Text("حالة الأعمال", color = Green, fontWeight = FontWeight.Bold)
                val completed = pieces.count { it.optString("status") == "completed" || it.optString("status") == "delivered" }
                FinanceLine("مكتملة أو تم تسليمها", "$completed من ${pieces.size}")
                Text("المصروفات حسب السجل", color = Green, fontWeight = FontWeight.Bold)
                expenses.forEach { r -> FinanceLine("${r.optString("category")} • ${r.optString("description")}", "${r.optString("amount")} ج.م") }
            }
            Text("الفترة: $fromDate إلى $toDate", color = Muted, fontSize = 11.sp)
        }
    }
}


@Composable
private fun InvoiceDraftForm(accessToken: String, onCancel: () -> Unit, onCreated: () -> Unit) {
    val scope = rememberCoroutineScope()
    val today = remember { LocalDate.now() }
    val monday = remember { today.minusDays((today.dayOfWeek.value - 1).toLong()) }
    val saturday = monday.plusDays(5)
    var customers by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var pieces by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var selectedCustomer by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(accessToken) {
        try {
            withContext(Dispatchers.IO) {
                val c = SupabaseData.select("app_customers", accessToken, "select=id,name&order=name.asc&limit=1000")
                customers = (0 until c.length()).map { c.getJSONObject(it) }
                if (customers.isNotEmpty()) selectedCustomer = customers.first().optString("id")
            }
        } catch (e: Exception) { message = e.message ?: "تعذر تحميل العملاء" } finally { loading = false }
    }
    Column(Modifier.fillMaxWidth().background(White, RoundedCornerShape(16.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("إنشاء مسودة فاتورة أسبوعية", color = Green, fontWeight = FontWeight.Bold)
        Text("الفترة: $monday إلى $saturday", color = Muted, fontSize = 12.sp)
        Box {
            OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                Text(customers.firstOrNull { it.optString("id") == selectedCustomer }?.optString("name") ?: "اختيار العميل")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                customers.forEach { c -> DropdownMenuItem(text = { Text(c.optString("name")) }, onClick = { selectedCustomer = c.optString("id"); menu = false; pieces = emptyList() }) }
            }
        }
        Button(onClick = { scope.launch {
            loading = true; message = null
            try {
                val pid = selectedCustomer.toLong()
                pieces = withContext(Dispatchers.IO) {
                    val all = SupabaseData.select("app_pieces", accessToken, "select=id,customer_id,received_at,item_type,description,price&customer_id=eq.$pid&received_at=gte.${monday}T00:00:00&received_at=lte.${saturday}T23:59:59&order=received_at.asc&limit=1000")
                    val itemRows = SupabaseData.select("app_invoice_items", accessToken, "select=piece_id&limit=10000")
                    val invoiced = (0 until itemRows.length()).map { itemRows.getJSONObject(it).optLong("piece_id") }.toSet()
                    (0 until all.length()).map { all.getJSONObject(it) }.filter { !invoiced.contains(it.optLong("id")) }
                }
                if (pieces.isEmpty()) message = "لا توجد قطع غير مفوترة لهذا العميل خلال الأسبوع"
            } catch (e: Exception) { message = e.message ?: "تعذر تحميل القطع" } finally { loading = false }
        } }, enabled = selectedCustomer.isNotBlank() && !loading, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("تحميل القطع غير المفوترة", color = White) }
        if (pieces.isNotEmpty()) {
            val total = pieces.fold(java.math.BigDecimal.ZERO) { a, r -> a + (r.optString("price").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO) }
            Text("${pieces.size} قطعة — الإجمالي ${total.toPlainString()} ج.م", color = Green, fontWeight = FontWeight.Bold)
            pieces.forEach { Text("${it.optString("item_type")} • ${it.optString("price")} ج.م", color = Ink, fontSize = 12.sp) }
            Button(onClick = { saving = true; scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val current = SupabaseData.select("app_invoices", accessToken, "select=invoice_number&order=invoice_number.desc&limit=1")
                        val nextNumber = if (current.length() == 0) 1L else current.getJSONObject(0).optLong("invoice_number") + 1L
                        val invoice = JSONObject().put("invoice_number", nextNumber).put("customer_id", selectedCustomer.toLong()).put("week_start", monday.toString()).put("week_end", saturday.toString()).put("subtotal", total).put("adjustments", 0).put("total_amount", total).put("status", "draft").put("created_at", java.time.OffsetDateTime.now().toString())
                        val created = SupabaseData.insert("app_invoices", accessToken, invoice)
                        check(created.length() > 0) { "لم يتم إنشاء الفاتورة" }
                        val invoiceId = created.getJSONObject(0).getLong("id")
                        pieces.forEach { p ->
                            val price = p.optString("price").toBigDecimalOrNull() ?: java.math.BigDecimal.ZERO
                            SupabaseData.insert("app_invoice_items", accessToken, JSONObject().put("invoice_id", invoiceId).put("piece_id", p.optLong("id")).put("description", listOf(p.optString("item_type"), p.optString("description")).filter { it.isNotBlank() && it != "null" }.joinToString(" - ")).put("quantity", 1).put("unit_price", price).put("line_total", price).put("created_at", java.time.OffsetDateTime.now().toString()))
                        }
                    }
                    onCreated()
                } catch (e: Exception) { message = "تعذر إنشاء الفاتورة: ${e.message}" } finally { saving = false }
            } }, enabled = !saving, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                if (saving) CircularProgressIndicator(Modifier.size(18.dp), color = White) else Text("إنشاء مسودة الفاتورة", color = White)
            }
        }
        if (message != null) Text(message!!, color = if (message!!.startsWith("لا توجد")) Muted else MaterialTheme.colorScheme.error, fontSize = 12.sp)
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
    }
}

private fun shareInvoicePdf(context: android.content.Context, invoice: JSONObject, customerName: String, items: List<JSONObject>) {
    try {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val title = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 22f; color = android.graphics.Color.rgb(23,72,61); typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
        val normal = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 14f; color = android.graphics.Color.DKGRAY }
        val bold = android.graphics.Paint(normal).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD }
        canvas.drawText("ASHRAF ARTIN", 40f, 55f, title)
        canvas.drawText("INVOICE #${invoice.optString("invoice_number")}", 40f, 95f, title)
        canvas.drawText("Customer: $customerName", 40f, 135f, normal)
        canvas.drawText("Period: ${invoice.optString("week_start")} - ${invoice.optString("week_end")}", 40f, 160f, normal)
        canvas.drawLine(40f, 185f, 555f, 185f, bold)
        canvas.drawText("Description", 42f, 215f, bold)
        canvas.drawText("Qty", 350f, 215f, bold)
        canvas.drawText("Unit", 410f, 215f, bold)
        canvas.drawText("Total", 490f, 215f, bold)
        var y = 250f
        items.take(22).forEach { row ->
            canvas.drawText(row.optString("description").take(38), 42f, y, normal)
            canvas.drawText(row.optString("quantity"), 355f, y, normal)
            canvas.drawText(row.optString("unit_price"), 410f, y, normal)
            canvas.drawText(row.optString("line_total"), 490f, y, normal)
            y += 25f
        }
        canvas.drawLine(40f, y + 10f, 555f, y + 10f, bold)
        canvas.drawText("Subtotal: ${invoice.optString("subtotal")} EGP", 350f, y + 42f, bold)
        canvas.drawText("Adjustments: ${invoice.optString("adjustments")} EGP", 350f, y + 67f, normal)
        canvas.drawText("TOTAL: ${invoice.optString("total_amount")} EGP", 350f, y + 100f, title)
        canvas.drawText("Status: ${invoice.optString("status")}", 40f, 790f, normal)
        document.finishPage(page)
        val dir = File(context.cacheDir, "shared_invoices").apply { mkdirs() }
        val file = File(dir, "invoice_${invoice.optString("invoice_number")}.pdf")
        file.outputStream().use { document.writeTo(it) }
        document.close()
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "فاتورة أشرف أرتين رقم ${invoice.optString("invoice_number")}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "إرسال الفاتورة عبر واتساب أو تطبيق آخر"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "تعذر تجهيز ملف الفاتورة: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun FinanceMetric(label: String, value: java.math.BigDecimal) {
    Surface(color = White, shape = RoundedCornerShape(14.dp), shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Ink, fontWeight = FontWeight.SemiBold)
            Text("${value.setScale(2, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()} ج.م", color = Green, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FinanceLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
