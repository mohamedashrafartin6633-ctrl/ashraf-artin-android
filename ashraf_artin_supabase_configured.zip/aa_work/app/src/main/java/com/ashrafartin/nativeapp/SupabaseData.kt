package com.ashrafartin.nativeapp

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Authenticated Supabase REST access. Every request uses the signed-in user's JWT;
 * authorization remains enforced by PostgreSQL RLS, never by this client alone. */
internal object SupabaseData {
    private fun request(method: String, path: String, accessToken: String, body: String? = null,
                        prefer: String? = null): String {
        require(BuildConfig.SUPABASE_URL.isNotBlank()) { "SUPABASE_URL غير مضبوط" }
        require(BuildConfig.SUPABASE_PUBLISHABLE_KEY.isNotBlank()) { "Publishable Key غير مضبوط" }
        val c = (URL(BuildConfig.SUPABASE_URL.trimEnd('/') + path).openConnection() as HttpURLConnection)
        try {
            c.requestMethod = method
            c.connectTimeout = 20000
            c.readTimeout = 20000
            c.setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            c.setRequestProperty("Authorization", "Bearer $accessToken")
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Content-Type", "application/json")
            if (prefer != null) c.setRequestProperty("Prefer", prefer)
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = try { JSONObject(response).optString("message").ifBlank { JSONObject(response).optString("details") } } catch (_: Exception) { response }
                throw IllegalStateException("Supabase HTTP $code: ${detail.ifBlank { "تعذر تنفيذ العملية" }}")
            }
            return response
        } finally { c.disconnect() }
    }

    fun currentUser(accessToken: String): JSONObject = JSONObject(
        request("GET", "/auth/v1/user", accessToken)
    )

    fun profile(userId: String, accessToken: String): JSONObject {
        val id = URLEncoder.encode(userId, "UTF-8")
        val result = JSONArray(request("GET", "/rest/v1/profiles?id=eq.$id&select=id,username,role,is_active", accessToken))
        check(result.length() == 1) { "لم يتم العثور على ملف المستخدم في profiles" }
        val profile = result.getJSONObject(0)
        check(profile.optBoolean("is_active", false)) { "هذا الحساب غير نشط. راجع مالك الورشة" }
        val role = profile.optString("role")
        check(role == "owner" || role == "employee") { "دور المستخدم غير معروف" }
        return profile
    }

    fun select(table: String, accessToken: String, query: String = "select=*"): JSONArray {
        require(table.matches(Regex("app_[a-z_]+"))) { "اسم جدول غير مسموح" }
        return JSONArray(request("GET", "/rest/v1/$table?$query", accessToken))
    }

    fun insert(table: String, accessToken: String, values: JSONObject): JSONArray {
        require(table.matches(Regex("app_[a-z_]+"))) { "اسم جدول غير مسموح" }
        return JSONArray(request("POST", "/rest/v1/$table", accessToken, values.toString(), "return=representation"))
    }

    fun update(table: String, accessToken: String, filter: String, values: JSONObject): JSONArray {
        require(table.matches(Regex("app_[a-z_]+"))) { "اسم جدول غير مسموح" }
        require(filter.startsWith("id=eq.")) { "يجب تحديد السجل بالمعرف" }
        return JSONArray(request("PATCH", "/rest/v1/$table?$filter", accessToken, values.toString(), "return=representation"))
    }

    fun delete(table: String, accessToken: String, filter: String) {
        require(table.matches(Regex("app_[a-z_]+"))) { "اسم جدول غير مسموح" }
        require(filter.startsWith("id=eq.")) { "يجب تحديد السجل بالمعرف" }
        request("DELETE", "/rest/v1/$table?$filter", accessToken, prefer = "return=minimal")
    }

    fun refresh(refreshToken: String): Pair<String, String> {
        val endpoint = BuildConfig.SUPABASE_URL.trimEnd('/') + "/auth/v1/token?grant_type=refresh_token"
        val c = (URL(endpoint).openConnection() as HttpURLConnection)
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
            c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("refresh_token", refreshToken).toString()
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("انتهت الجلسة، سجّل الدخول مرة أخرى")
            val json = JSONObject(raw)
            return json.getString("access_token") to json.getString("refresh_token")
        } finally { c.disconnect() }
    }
}
